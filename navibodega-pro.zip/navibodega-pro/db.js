// ============================================================
// NaviBodega Pro - Módulo de Base de Datos y Persistencia
// Tienda de Abarrotes y Víveres
// Moneda Oficial: Soles (S/) - Precios por Kilo y Unidad
// ============================================================

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const DATA_DIR = path.join(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
}

const DB_PATH = path.join(DATA_DIR, 'navibodega.db');
const JSON_BACKUP_PATH = path.join(DATA_DIR, 'navibodega.json');

// --- HASHING UTILITIES ---
function hashPassword(password) {
    const salt = crypto.randomBytes(16).toString('hex');
    const hash = crypto.scryptSync(password, salt, 64).toString('hex');
    return `${salt}:${hash}`;
}

function verifyPassword(password, stored) {
    if (!stored || !stored.includes(':')) return false;
    const [salt, hash] = stored.split(':');
    const testHash = crypto.scryptSync(password, salt, 64).toString('hex');
    return crypto.timingSafeEqual(Buffer.from(hash, 'hex'), Buffer.from(testHash, 'hex'));
}

// --- PRODUCTOS DE TIENDA DE ABARROTES (PRECIOS EN SOLES POR KILO / UNIDAD) ---
const DEFAULT_PRODUCTS = [
    // 1. Abarrotes y Granos (Por Kilo / Envase)
    { id: 'AB-01', name: 'Arroz Superior', category: 'Abarrotes y Granos', unit: 'Kilo', price: 4.20, stock: 120, minStock: 20, icon: 'fa-wheat-awn', description: 'Arroz seleccionado de grano largo por kilo.' },
    { id: 'AB-02', name: 'Arroz Extra Costeño', category: 'Abarrotes y Granos', unit: 'Kilo', price: 4.80, stock: 100, minStock: 20, icon: 'fa-wheat-awn', description: 'Arroz extra añejo de calidad superior por kilo.' },
    { id: 'AB-03', name: 'Azúcar Rubia Doméstica', category: 'Abarrotes y Granos', unit: 'Kilo', price: 3.80, stock: 90, minStock: 15, icon: 'fa-cube', description: 'Azúcar rubia dulce pura de caña por kilo.' },
    { id: 'AB-04', name: 'Azúcar Blanca Refinada', category: 'Abarrotes y Granos', unit: 'Kilo', price: 4.20, stock: 80, minStock: 15, icon: 'fa-cube', description: 'Azúcar blanca refinada por kilo.' },
    { id: 'AB-05', name: 'Harina de Trigo Preparada', category: 'Abarrotes y Granos', unit: 'Kilo', price: 4.00, stock: 60, minStock: 10, icon: 'fa-bowl-rice', description: 'Harina con polvo de hornear por kilo.' },
    { id: 'AB-06', name: 'Harina sin Preparar', category: 'Abarrotes y Granos', unit: 'Kilo', price: 3.50, stock: 70, minStock: 10, icon: 'fa-bowl-rice', description: 'Harina de trigo tradicional por kilo.' },
    { id: 'AB-07', name: 'Lentejas Seleccionadas', category: 'Abarrotes y Granos', unit: 'Kilo', price: 5.80, stock: 50, minStock: 10, icon: 'fa-seedling', description: 'Menestra de cocción rápida por kilo.' },
    { id: 'AB-08', name: 'Frejol Canario', category: 'Abarrotes y Granos', unit: 'Kilo', price: 7.50, stock: 40, minStock: 10, icon: 'fa-seedling', description: 'Frejol suave de primera calidad por kilo.' },
    { id: 'AB-09', name: 'Fideos Espagueti Don Vittorio', category: 'Abarrotes y Granos', unit: 'Paquete 500g', price: 3.60, stock: 80, minStock: 15, icon: 'fa-utensils', description: 'Pasta larga de sémola de trigo durum.' },
    { id: 'AB-10', name: 'Fideos Tallarín Grueso', category: 'Abarrotes y Granos', unit: 'Paquete 500g', price: 3.40, stock: 75, minStock: 15, icon: 'fa-utensils', description: 'Tallarines ideales para guisos y sopas.' },
    { id: 'AB-11', name: 'Aceite Vegetal Primor / Cocinero', category: 'Abarrotes y Granos', unit: 'Botella 1 Litro', price: 8.50, stock: 65, minStock: 12, icon: 'fa-bottle-droplet', description: 'Aceite vegetal comestible puro.' },
    { id: 'AB-12', name: 'Sal de Mesa Yodada', category: 'Abarrotes y Granos', unit: 'Kilo', price: 1.80, stock: 100, minStock: 20, icon: 'fa-cubes-stacked', description: 'Sal refinada marina yodada por kilo.' },

    // 2. Conservas y Enlatados
    { id: 'CN-01', name: 'Filete de Atún en Aceite Campomar', category: 'Conservas y Enlatados', unit: 'Lata 170g', price: 5.80, stock: 90, minStock: 20, icon: 'fa-fish', description: 'Lomo fino de atún en aceite vegetal.' },
    { id: 'CN-02', name: 'Atún en Trozos Primor', category: 'Conservas y Enlatados', unit: 'Lata 170g', price: 4.90, stock: 110, minStock: 25, icon: 'fa-fish', description: 'Trozos de atún claro en aceite vegetal.' },
    { id: 'CN-03', name: 'Grated de Pescado', category: 'Conservas y Enlatados', unit: 'Lata 170g', price: 3.80, stock: 80, minStock: 15, icon: 'fa-fish', description: 'Pescado desmenuzado económico para rancho.' },
    { id: 'CN-04', name: 'Sardinas en Salsa de Tomate', category: 'Conservas y Enlatados', unit: 'Lata 425g', price: 6.50, stock: 50, minStock: 10, icon: 'fa-fish-fins', description: 'Sardinas enteras ovaladas en salsa roja.' },
    { id: 'CN-05', name: 'Leche Evaporada Entera Gloria', category: 'Conservas y Enlatados', unit: 'Tarro 400g', price: 4.30, stock: 120, minStock: 25, icon: 'fa-cow', description: 'Leche evaporada con vitaminas A y D.' },
    { id: 'CN-06', name: 'Leche Evaporada Deslactosada', category: 'Conservas y Enlatados', unit: 'Tarro 400g', price: 4.60, stock: 50, minStock: 10, icon: 'fa-cow', description: 'Leche evaporada de fácil digestión.' },

    // 3. Verduras y Tubérculos (Por Kilo)
    { id: 'VR-01', name: 'Papa Blanca Canchán', category: 'Verduras y Frescos', unit: 'Kilo', price: 2.50, stock: 150, minStock: 30, icon: 'fa-carrot', description: 'Papa fresca lavada especial para frituras y guisos por kilo.' },
    { id: 'VR-02', name: 'Papa Amarilla Tumbay', category: 'Verduras y Frescos', unit: 'Kilo', price: 4.00, stock: 100, minStock: 20, icon: 'fa-carrot', description: 'Papa amarilla arenosa para puré y caldos por kilo.' },
    { id: 'VR-03', name: 'Cebolla Roja', category: 'Verduras y Frescos', unit: 'Kilo', price: 3.20, stock: 120, minStock: 25, icon: 'fa-apple-whole', description: 'Cebolla roja seleccionada de aderezo por kilo.' },
    { id: 'VR-04', name: 'Tomate Italiano', category: 'Verduras y Frescos', unit: 'Kilo', price: 3.50, stock: 80, minStock: 15, icon: 'fa-apple-whole', description: 'Tomates maduros y frescos por kilo.' },
    { id: 'VR-05', name: 'Zanahoria Fresca', category: 'Verduras y Frescos', unit: 'Kilo', price: 2.20, stock: 90, minStock: 15, icon: 'fa-carrot', description: 'Zanahorias dulces y crujientes por kilo.' },
    { id: 'VR-06', name: 'Limón Sutil Verde', category: 'Verduras y Frescos', unit: 'Kilo', price: 4.50, stock: 60, minStock: 12, icon: 'fa-lemon', description: 'Limones con abundante jugo por kilo.' },
    { id: 'VR-07', name: 'Camote Amarillo', category: 'Verduras y Frescos', unit: 'Kilo', price: 2.80, stock: 60, minStock: 10, icon: 'fa-carrot', description: 'Camotes dulces horneables por kilo.' },

    // 4. Carnes y Huevos (Por Kilo)
    { id: 'CR-01', name: 'Pollo Entero Fresco', category: 'Carnes y Huevos', unit: 'Kilo', price: 9.80, stock: 80, minStock: 15, icon: 'fa-drumstick-bite', description: 'Pollo limpio eviscerado fresco por kilo.' },
    { id: 'CR-02', name: 'Pechuga de Pollo', category: 'Carnes y Huevos', unit: 'Kilo', price: 14.50, stock: 50, minStock: 10, icon: 'fa-drumstick-bite', description: 'Pechuga entera de pollo sin menudencia por kilo.' },
    { id: 'CR-03', name: 'Carne de Res para Guiso', category: 'Carnes y Huevos', unit: 'Kilo', price: 27.00, stock: 40, minStock: 8, icon: 'fa-drumstick-bite', description: 'Carne de res tierna en trozos por kilo.' },
    { id: 'CR-04', name: 'Bistec de Res', category: 'Carnes y Huevos', unit: 'Kilo', price: 32.00, stock: 35, minStock: 8, icon: 'fa-drumstick-bite', description: 'Cortes finos para sartén por kilo.' },
    { id: 'CR-05', name: 'Chuleta de Cerdo', category: 'Carnes y Huevos', unit: 'Kilo', price: 18.50, stock: 30, minStock: 6, icon: 'fa-bacon', description: 'Chuletas frescas de cerdo por kilo.' },
    { id: 'CR-06', name: 'Huevos Frescos de Granja', category: 'Carnes y Huevos', unit: 'Kilo', price: 8.50, stock: 70, minStock: 15, icon: 'fa-egg', description: 'Aproximadamente 16 unidades por kilo.' },

    // 5. Galletas, Snacks y Desayuno
    { id: 'GK-01', name: 'Galletas de Soda San Jorge', category: 'Galletas y Desayuno', unit: 'Paquete 6 unid.', price: 4.50, stock: 65, minStock: 15, icon: 'fa-cookie', description: 'Pack familiar de galletas de soda crocantes.' },
    { id: 'GK-02', name: 'Galletas Margarita Field', category: 'Galletas y Desayuno', unit: 'Paquete 6 unid.', price: 5.20, stock: 60, minStock: 15, icon: 'fa-cookie-bite', description: 'Galletas dulces tradicionales con salpicaduras de azúcar.' },
    { id: 'GK-03', name: 'Galletas Rellenitas Chocolate', category: 'Galletas y Desayuno', unit: 'Paquete 6 unid.', price: 4.80, stock: 55, minStock: 12, icon: 'fa-cookie', description: 'Galletas rellenas con crema de chocolate.' },
    { id: 'GK-04', name: 'Galletas Vainilla Field', category: 'Galletas y Desayuno', unit: 'Paquete 6 unid.', price: 4.50, stock: 60, minStock: 12, icon: 'fa-cookie-bite', description: 'Galletas crujientes de vainilla.' },
    { id: 'GK-05', name: 'Galletas Casino Menta / Choc', category: 'Galletas y Desayuno', unit: 'Paquete 6 unid.', price: 5.50, stock: 50, minStock: 10, icon: 'fa-cookie', description: 'Galletas de chocolate con crema de menta.' },
    { id: 'GK-06', name: 'Avena en Hojuelas', category: 'Galletas y Desayuno', unit: 'Bolsa 500g', price: 3.50, stock: 70, minStock: 15, icon: 'fa-bowl-rice', description: 'Hojuelas de avena instantánea para desayuno.' },
    { id: 'GK-07', name: 'Café Instantáneo Nescafé', category: 'Galletas y Desayuno', unit: 'Frasco 100g', price: 12.50, stock: 45, minStock: 10, icon: 'fa-mug-hot', description: 'Café soluble puro 100% sabor clásico.' },
    { id: 'GK-08', name: 'Té e Infusiones Surtidas', category: 'Galletas y Desayuno', unit: 'Caja 25 sobres', price: 4.50, stock: 60, minStock: 12, icon: 'fa-mug-saucer', description: 'Manzanilla, anís y té negro.' },

    // 6. Bebidas y Aguas
    { id: 'BB-01', name: 'Agua de Mesa sin Gas', category: 'Bebidas y Aguas', unit: 'Botella 2.5 Litros', price: 3.50, stock: 80, minStock: 15, icon: 'fa-bottle-water', description: 'Agua purificada refrescante en botella grande.' },
    { id: 'BB-02', name: 'Agua en Bidón', category: 'Bebidas y Aguas', unit: 'Bidón 7 Litros', price: 7.50, stock: 60, minStock: 15, icon: 'fa-glass-water', description: 'Bidón económico para abastecimiento de agua.' },
    { id: 'BB-03', name: 'Gaseosa Inca Kola', category: 'Bebidas y Aguas', unit: 'Botella 3 Litros', price: 12.50, stock: 50, minStock: 10, icon: 'fa-wine-bottle', description: 'Gaseosa sabor nacional tamaño familiar.' },
    { id: 'BB-04', name: 'Gaseosa Coca Cola', category: 'Bebidas y Aguas', unit: 'Botella 3 Litros', price: 13.00, stock: 45, minStock: 10, icon: 'fa-wine-bottle', description: 'Gaseosa clásica familiar.' },
    { id: 'BB-05', name: 'Bebida Rehidratante Sporade', category: 'Bebidas y Aguas', unit: 'Botella 500ml', price: 2.50, stock: 90, minStock: 20, icon: 'fa-bolt', description: 'Bebida isotónica sabores variados.' },

    // 7. Limpieza del Hogar
    { id: 'LP-01', name: 'Detergente en Polvo Ariel / Bolívar', category: 'Limpieza del Hogar', unit: 'Bolsa 1 Kilo', price: 8.90, stock: 70, minStock: 15, icon: 'fa-soap', description: 'Detergente con alto poder limpiador y aroma agradable.' },
    { id: 'LP-02', name: 'Lavavajillas en Pasta Ayudín', category: 'Limpieza del Hogar', unit: 'Pote 450g', price: 3.80, stock: 80, minStock: 15, icon: 'fa-pump-soap', description: 'Pasta quitagrasa con aroma a limón.' },
    { id: 'LP-03', name: 'Lejía Tradicional Clorox', category: 'Limpieza del Hogar', unit: 'Botella 1 Litro', price: 3.20, stock: 65, minStock: 12, icon: 'fa-bottle-droplet', description: 'Desinfectante y blanqueador para pisos y superficies.' },
    { id: 'LP-04', name: 'Jabón de Tocador', category: 'Limpieza del Hogar', unit: 'Pack 3 unid.', price: 7.50, stock: 60, minStock: 12, icon: 'fa-bath', description: 'Jabón en barra para higiene personal.' },
    { id: 'LP-05', name: 'Papel Higiénico Suave / Elite', category: 'Limpieza del Hogar', unit: 'Paquete 4 rollos', price: 5.20, stock: 90, minStock: 20, icon: 'fa-toilet-paper', description: 'Papel higiénico doble hoja suave.' },
    { id: 'LP-06', name: 'Bolsas de Basura Gruesas', category: 'Limpieza del Hogar', unit: 'Paquete 10 unid.', price: 3.50, stock: 80, minStock: 15, icon: 'fa-trash', description: 'Bolsas resistentes para tachos medianos.' }
];

// --- SQLITE DRIVER INITIALIZATION ---
let sqliteDb = null;
let useSqlite = false;

try {
    const { DatabaseSync } = require('node:sqlite');
    sqliteDb = new DatabaseSync(DB_PATH);
    useSqlite = true;
    console.log('[NaviBodega DB] Conectado a SQLite nativo en:', DB_PATH);
} catch (err) {
    console.warn('[NaviBodega DB] node:sqlite no disponible, usando motor de persistencia JSON:', err.message);
}

// --- SCHEMA SETUP & MIGRATION ---
function initDatabase() {
    if (useSqlite) {
        sqliteDb.exec(`
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                name TEXT NOT NULL,
                role TEXT NOT NULL,
                company TEXT DEFAULT '',
                vessel_name TEXT DEFAULT '',
                vessel_imo TEXT DEFAULT '',
                phone TEXT DEFAULT '',
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS products (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                category TEXT NOT NULL,
                unit TEXT NOT NULL,
                price REAL NOT NULL,
                stock INTEGER NOT NULL,
                min_stock INTEGER DEFAULT 10,
                icon TEXT,
                description TEXT,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS orders (
                id TEXT PRIMARY KEY,
                client_id INTEGER NOT NULL,
                client_name TEXT NOT NULL,
                client_email TEXT NOT NULL,
                vessel_name TEXT NOT NULL,
                vessel_imo TEXT DEFAULT '',
                captain TEXT NOT NULL,
                dock_port TEXT DEFAULT '',
                departure_date TEXT NOT NULL,
                status TEXT NOT NULL,
                notes TEXT,
                admin_notes TEXT,
                subtotal REAL DEFAULT 0,
                delivery_fee REAL DEFAULT 0,
                total REAL DEFAULT 0,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                FOREIGN KEY (client_id) REFERENCES users(id)
            );

            CREATE TABLE IF NOT EXISTS order_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                order_id TEXT NOT NULL,
                product_id TEXT NOT NULL,
                name TEXT NOT NULL,
                category TEXT NOT NULL,
                unit TEXT NOT NULL,
                quantity INTEGER NOT NULL,
                unit_price REAL NOT NULL,
                subtotal REAL NOT NULL,
                FOREIGN KEY (order_id) REFERENCES orders(id)
            );

            CREATE TABLE IF NOT EXISTS logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                action TEXT NOT NULL,
                user_email TEXT,
                details TEXT,
                created_at TEXT NOT NULL
            );
        `);

        // Check if seeded
        const userCount = sqliteDb.prepare('SELECT COUNT(*) as count FROM users').get().count;
        if (userCount === 0) {
            seedInitialDataSqlite();
        }
    } else {
        if (!fs.existsSync(JSON_BACKUP_PATH)) {
            seedInitialDataJson();
        }
    }
}

function seedInitialDataSqlite() {
    console.log('[NaviBodega DB] Poblando productos de abarrotes en Soles (S/)...');
    
    // Seed Users
    const insertUser = sqliteDb.prepare(`
        INSERT INTO users (email, password, name, role, company, vessel_name, vessel_imo, phone, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    // Admin default
    insertUser.run(
        'admin@navibodega.com',
        hashPassword('admin123'),
        'Carlos Naveda (Administrador de Bodega)',
        'admin',
        'Bodega de Abarrotes El Puerto',
        'Bodega Central',
        '',
        '987 654 321',
        new Date().toISOString()
    );

    // Client default 1
    insertUser.run(
        'capitan@pesquero.com',
        hashPassword('cliente123'),
        'Roberto Gómez',
        'cliente',
        'Pesquera del Mar',
        'Barco San Martín',
        '',
        '999 111 222',
        new Date().toISOString()
    );

    // Seed Products
    const insertProduct = sqliteDb.prepare(`
        INSERT INTO products (id, name, category, unit, price, stock, min_stock, icon, description, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    for (const p of DEFAULT_PRODUCTS) {
        insertProduct.run(p.id, p.name, p.category, p.unit, p.price, p.stock, p.minStock, p.icon, p.description, new Date().toISOString());
    }

    // Seed Initial Orders in Soles
    const insertOrder = sqliteDb.prepare(`
        INSERT INTO orders (id, client_id, client_name, client_email, vessel_name, vessel_imo, captain, dock_port, departure_date, status, notes, admin_notes, subtotal, delivery_fee, total, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const insertItem = sqliteDb.prepare(`
        INSERT INTO order_items (order_id, product_id, name, category, unit, quantity, unit_price, subtotal)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);

    // Order 1: Pendiente de Cotización
    const o1Id = 'PED-2026-101';
    insertOrder.run(
        o1Id,
        2,
        'Roberto Gómez',
        'capitan@pesquero.com',
        'Barco San Martín',
        '',
        'Roberto Gómez',
        '',
        '2026-11-12 08:00',
        'Pendiente de Cotización',
        'Por favor enviar las verduras frescas y la carne empacada en bolsas.',
        '',
        138.40,
        15.00,
        153.40,
        '2026-11-05 10:30',
        '2026-11-05 10:30'
    );
    insertItem.run(o1Id, 'AB-01', 'Arroz Superior', 'Abarrotes y Granos', 'Kilo', 10, 4.20, 42.00);
    insertItem.run(o1Id, 'VR-01', 'Papa Blanca Canchán', 'Verduras y Frescos', 'Kilo', 8, 2.50, 20.00);
    insertItem.run(o1Id, 'CR-01', 'Pollo Entero Fresco', 'Carnes y Huevos', 'Kilo', 5, 9.80, 49.00);
    insertItem.run(o1Id, 'CN-01', 'Filete de Atún en Aceite Campomar', 'Conservas y Enlatados', 'Lata 170g', 4, 5.80, 23.20);
    insertItem.run(o1Id, 'GK-01', 'Galletas de Soda San Jorge', 'Galletas y Desayuno', 'Paquete 6 unid.', 1, 4.50, 4.50);

    console.log('[NaviBodega DB] Productos de abarrotes cargados con éxito en SQLite.');
}

function seedInitialDataJson() {
    const data = {
        users: [
            {
                id: 1,
                email: 'admin@navibodega.com',
                password: hashPassword('admin123'),
                name: 'Carlos Naveda (Administrador de Bodega)',
                role: 'admin',
                company: 'Bodega de Abarrotes El Puerto',
                vessel_name: 'Bodega Central',
                vessel_imo: '',
                phone: '987 654 321',
                created_at: new Date().toISOString()
            },
            {
                id: 2,
                email: 'capitan@pesquero.com',
                password: hashPassword('cliente123'),
                name: 'Roberto Gómez',
                role: 'cliente',
                company: 'Pesquera del Mar',
                vessel_name: 'Barco San Martín',
                vessel_imo: '',
                phone: '999 111 222',
                created_at: new Date().toISOString()
            }
        ],
        products: DEFAULT_PRODUCTS.map(p => ({ ...p, created_at: new Date().toISOString() })),
        orders: [],
        logs: []
    };
    fs.writeFileSync(JSON_BACKUP_PATH, JSON.stringify(data, null, 2));
}

// --- DATABASE ACCESS API ---
const db = {
    init: initDatabase,
    verifyPassword,
    hashPassword,

    getUserByEmail(email) {
        if (useSqlite) {
            return sqliteDb.prepare('SELECT * FROM users WHERE LOWER(email) = LOWER(?)').get(email) || null;
        }
        const data = JSON.parse(fs.readFileSync(JSON_BACKUP_PATH, 'utf8'));
        return data.users.find(u => u.email.toLowerCase() === email.toLowerCase()) || null;
    },

    getUserById(id) {
        if (useSqlite) {
            return sqliteDb.prepare('SELECT id, email, name, role, company, vessel_name, vessel_imo, phone, created_at FROM users WHERE id = ?').get(id) || null;
        }
        const data = JSON.parse(fs.readFileSync(JSON_BACKUP_PATH, 'utf8'));
        const u = data.users.find(u => u.id === id);
        if (!u) return null;
        const { password, ...safeUser } = u;
        return safeUser;
    },

    getAllUsers() {
        if (useSqlite) {
            return sqliteDb.prepare('SELECT id, email, name, role, company, vessel_name, vessel_imo, phone, created_at FROM users ORDER BY id DESC').all();
        }
        const data = JSON.parse(fs.readFileSync(JSON_BACKUP_PATH, 'utf8'));
        return data.users.map(({ password, ...u }) => u);
    },

    createUser(userData) {
        const hashedPassword = hashPassword(userData.password);
        const createdAt = new Date().toISOString();

        if (useSqlite) {
            const stmt = sqliteDb.prepare(`
                INSERT INTO users (email, password, name, role, company, vessel_name, vessel_imo, phone, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            `);
            const res = stmt.run(
                userData.email,
                hashedPassword,
                userData.name,
                userData.role || 'cliente',
                userData.company || '',
                userData.vessel_name || '',
                userData.vessel_imo || '',
                userData.phone || '',
                createdAt
            );
            return this.getUserById(res.lastInsertRowid);
        }

        const data = JSON.parse(fs.readFileSync(JSON_BACKUP_PATH, 'utf8'));
        const newId = data.users.length ? Math.max(...data.users.map(u => u.id)) + 1 : 1;
        const newUser = {
            id: newId,
            email: userData.email,
            password: hashedPassword,
            name: userData.name,
            role: userData.role || 'cliente',
            company: userData.company || '',
            vessel_name: userData.vessel_name || '',
            vessel_imo: userData.vessel_imo || '',
            phone: userData.phone || '',
            created_at: createdAt
        };
        data.users.push(newUser);
        fs.writeFileSync(JSON_BACKUP_PATH, JSON.stringify(data, null, 2));
        const { password, ...safeUser } = newUser;
        return safeUser;
    },

    getAllProducts() {
        if (useSqlite) {
            return sqliteDb.prepare('SELECT * FROM products ORDER BY category ASC, name ASC').all();
        }
        const data = JSON.parse(fs.readFileSync(JSON_BACKUP_PATH, 'utf8'));
        return data.products;
    },

    getProductById(id) {
        if (useSqlite) {
            return sqliteDb.prepare('SELECT * FROM products WHERE id = ?').get(id) || null;
        }
        const data = JSON.parse(fs.readFileSync(JSON_BACKUP_PATH, 'utf8'));
        return data.products.find(p => p.id === id) || null;
    },

    createProduct(p) {
        const id = p.id || 'PROD-' + Date.now().toString().slice(-6);
        const createdAt = new Date().toISOString();
        if (useSqlite) {
            const stmt = sqliteDb.prepare(`
                INSERT INTO products (id, name, category, unit, price, stock, min_stock, icon, description, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            `);
            stmt.run(id, p.name, p.category, p.unit, Number(p.price), parseInt(p.stock), parseInt(p.min_stock || 10), p.icon || 'fa-box', p.description || '', createdAt);
            return this.getProductById(id);
        }
        const data = JSON.parse(fs.readFileSync(JSON_BACKUP_PATH, 'utf8'));
        const newProd = { id, ...p, price: Number(p.price), stock: parseInt(p.stock), min_stock: parseInt(p.min_stock || 10), created_at: createdAt };
        data.products.push(newProd);
        fs.writeFileSync(JSON_BACKUP_PATH, JSON.stringify(data, null, 2));
        return newProd;
    },

    updateProduct(id, p) {
        if (useSqlite) {
            const stmt = sqliteDb.prepare(`
                UPDATE products 
                SET name = ?, category = ?, unit = ?, price = ?, stock = ?, min_stock = ?, description = ?
                WHERE id = ?
            `);
            stmt.run(p.name, p.category, p.unit, Number(p.price), parseInt(p.stock), parseInt(p.min_stock || 10), p.description || '', id);
            return this.getProductById(id);
        }
        const data = JSON.parse(fs.readFileSync(JSON_BACKUP_PATH, 'utf8'));
        const idx = data.products.findIndex(prod => prod.id === id);
        if (idx !== -1) {
            data.products[idx] = { ...data.products[idx], ...p, price: Number(p.price), stock: parseInt(p.stock) };
            fs.writeFileSync(JSON_BACKUP_PATH, JSON.stringify(data, null, 2));
            return data.products[idx];
        }
        return null;
    },

    deleteProduct(id) {
        if (useSqlite) {
            sqliteDb.prepare('DELETE FROM products WHERE id = ?').run(id);
            return true;
        }
        const data = JSON.parse(fs.readFileSync(JSON_BACKUP_PATH, 'utf8'));
        data.products = data.products.filter(p => p.id !== id);
        fs.writeFileSync(JSON_BACKUP_PATH, JSON.stringify(data, null, 2));
        return true;
    },

    getAllOrders() {
        if (useSqlite) {
            const orders = sqliteDb.prepare('SELECT * FROM orders ORDER BY created_at DESC').all();
            const getItems = sqliteDb.prepare('SELECT * FROM order_items WHERE order_id = ?');
            return orders.map(o => ({
                ...o,
                items: getItems.all(o.id)
            }));
        }
        const data = JSON.parse(fs.readFileSync(JSON_BACKUP_PATH, 'utf8'));
        return data.orders.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
    },

    getOrdersByClientId(clientId) {
        if (useSqlite) {
            const orders = sqliteDb.prepare('SELECT * FROM orders WHERE client_id = ? ORDER BY created_at DESC').all(clientId);
            const getItems = sqliteDb.prepare('SELECT * FROM order_items WHERE order_id = ?');
            return orders.map(o => ({
                ...o,
                items: getItems.all(o.id)
            }));
        }
        const data = JSON.parse(fs.readFileSync(JSON_BACKUP_PATH, 'utf8'));
        return data.orders.filter(o => o.client_id === clientId).sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
    },

    getOrderById(id) {
        if (useSqlite) {
            const order = sqliteDb.prepare('SELECT * FROM orders WHERE id = ?').get(id);
            if (!order) return null;
            order.items = sqliteDb.prepare('SELECT * FROM order_items WHERE order_id = ?').all(id);
            return order;
        }
        const data = JSON.parse(fs.readFileSync(JSON_BACKUP_PATH, 'utf8'));
        return data.orders.find(o => o.id === id) || null;
    },

    createOrder(orderData, items) {
        const id = 'PED-' + new Date().getFullYear() + '-' + Math.floor(100 + Math.random() * 900);
        const now = new Date().toISOString().replace('T', ' ').substring(0, 16);

        let subtotal = 0;
        for (const it of items) {
            subtotal += (it.quantity * it.unit_price);
        }
        const deliveryFee = orderData.delivery_fee !== undefined ? Number(orderData.delivery_fee) : 15.00;
        const total = subtotal + deliveryFee;

        if (useSqlite) {
            const insertOrder = sqliteDb.prepare(`
                INSERT INTO orders (id, client_id, client_name, client_email, vessel_name, vessel_imo, captain, dock_port, departure_date, status, notes, admin_notes, subtotal, delivery_fee, total, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            `);

            insertOrder.run(
                id,
                orderData.client_id,
                orderData.client_name,
                orderData.client_email,
                orderData.vessel_name,
                orderData.vessel_imo || '',
                orderData.captain,
                orderData.dock_port || '',
                orderData.departure_date,
                orderData.status || 'Pendiente de Cotización',
                orderData.notes || '',
                orderData.admin_notes || '',
                subtotal,
                deliveryFee,
                total,
                now,
                now
            );

            const insertItem = sqliteDb.prepare(`
                INSERT INTO order_items (order_id, product_id, name, category, unit, quantity, unit_price, subtotal)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            `);

            for (const it of items) {
                const itemSubtotal = it.quantity * it.unit_price;
                insertItem.run(id, it.product_id, it.name, it.category || 'General', it.unit, it.quantity, it.unit_price, itemSubtotal);
            }

            return this.getOrderById(id);
        }

        const data = JSON.parse(fs.readFileSync(JSON_BACKUP_PATH, 'utf8'));
        const newOrder = {
            id,
            client_id: orderData.client_id,
            client_name: orderData.client_name,
            client_email: orderData.client_email,
            vessel_name: orderData.vessel_name,
            vessel_imo: orderData.vessel_imo || '',
            captain: orderData.captain,
            dock_port: orderData.dock_port || '',
            departure_date: orderData.departure_date,
            status: orderData.status || 'Pendiente de Cotización',
            notes: orderData.notes || '',
            admin_notes: orderData.admin_notes || '',
            subtotal,
            delivery_fee: deliveryFee,
            total,
            created_at: now,
            updated_at: now,
            items: items.map((it, idx) => ({
                id: idx + 1,
                order_id: id,
                product_id: it.product_id,
                name: it.name,
                category: it.category || 'General',
                unit: it.unit,
                quantity: it.quantity,
                unit_price: it.unit_price,
                subtotal: it.quantity * it.unit_price
            }))
        };
        data.orders.unshift(newOrder);
        fs.writeFileSync(JSON_BACKUP_PATH, JSON.stringify(data, null, 2));
        return newOrder;
    },

    updateOrderStatus(orderId, status, adminNotes = null) {
        const now = new Date().toISOString().replace('T', ' ').substring(0, 16);
        if (useSqlite) {
            if (adminNotes !== null) {
                sqliteDb.prepare('UPDATE orders SET status = ?, admin_notes = ?, updated_at = ? WHERE id = ?').run(status, adminNotes, now, orderId);
            } else {
                sqliteDb.prepare('UPDATE orders SET status = ?, updated_at = ? WHERE id = ?').run(status, now, orderId);
            }
            return this.getOrderById(orderId);
        }
        const data = JSON.parse(fs.readFileSync(JSON_BACKUP_PATH, 'utf8'));
        const o = data.orders.find(ord => ord.id === orderId);
        if (o) {
            o.status = status;
            if (adminNotes !== null) o.admin_notes = adminNotes;
            o.updated_at = now;
            fs.writeFileSync(JSON_BACKUP_PATH, JSON.stringify(data, null, 2));
            return o;
        }
        return null;
    },

    updateOrderQuote(orderId, items, deliveryFee, adminNotes, status) {
        const now = new Date().toISOString().replace('T', ' ').substring(0, 16);
        let subtotal = 0;

        if (useSqlite) {
            if (items && items.length) {
                const updateItem = sqliteDb.prepare('UPDATE order_items SET unit_price = ?, subtotal = ? WHERE id = ?');
                for (const it of items) {
                    const itemSub = it.quantity * it.unit_price;
                    subtotal += itemSub;
                    updateItem.run(it.unit_price, itemSub, it.id);
                }
            } else {
                const current = this.getOrderById(orderId);
                subtotal = current ? current.subtotal : 0;
            }

            const fee = deliveryFee !== undefined ? Number(deliveryFee) : 15.00;
            const total = subtotal + fee;

            sqliteDb.prepare(`
                UPDATE orders 
                SET subtotal = ?, delivery_fee = ?, total = ?, admin_notes = ?, status = ?, updated_at = ?
                WHERE id = ?
            `).run(subtotal, fee, total, adminNotes || '', status || 'Cotizado (Esperando Aprobación)', now, orderId);

            return this.getOrderById(orderId);
        }

        const data = JSON.parse(fs.readFileSync(JSON_BACKUP_PATH, 'utf8'));
        const ord = data.orders.find(o => o.id === orderId);
        if (!ord) return null;

        if (items && items.length) {
            for (const it of items) {
                const match = ord.items.find(i => i.id === it.id);
                if (match) {
                    match.unit_price = Number(it.unit_price);
                    match.subtotal = match.quantity * match.unit_price;
                }
            }
        }

        ord.subtotal = ord.items.reduce((s, i) => s + i.subtotal, 0);
        ord.delivery_fee = deliveryFee !== undefined ? Number(deliveryFee) : ord.delivery_fee;
        ord.total = ord.subtotal + ord.delivery_fee;
        if (adminNotes !== undefined) ord.admin_notes = adminNotes;
        if (status) ord.status = status;
        ord.updated_at = now;

        fs.writeFileSync(JSON_BACKUP_PATH, JSON.stringify(data, null, 2));
        return ord;
    },

    getStats() {
        const orders = this.getAllOrders();
        const products = this.getAllProducts();

        const pending = orders.filter(o => o.status === 'Pendiente de Cotización').length;
        const quoted = orders.filter(o => o.status.includes('Cotizado')).length;
        const inPrep = orders.filter(o => o.status === 'En Preparación y Embalaje' || o.status === 'Aprobado por Cliente').length;
        const completed = orders.filter(o => o.status === 'Entregado a Bordo').length;
        const totalRevenue = orders
            .filter(o => o.status === 'Entregado a Bordo' || o.status === 'En Preparación y Embalaje' || o.status === 'Aprobado por Cliente')
            .reduce((sum, o) => sum + (o.total || 0), 0);

        const lowStock = products.filter(p => p.stock <= p.min_stock).length;

        return {
            totalOrders: orders.length,
            pendingQuotes: pending,
            quotedOrders: quoted,
            inPreparation: inPrep,
            completedOrders: completed,
            totalRevenue,
            lowStockAlerts: lowStock,
            totalProducts: products.length
        };
    },

    resetDatabase() {
        if (useSqlite) {
            sqliteDb.exec(`
                DROP TABLE IF EXISTS order_items;
                DROP TABLE IF EXISTS orders;
                DROP TABLE IF EXISTS products;
                DROP TABLE IF EXISTS users;
                DROP TABLE IF EXISTS logs;
            `);
            initDatabase();
        } else {
            if (fs.existsSync(JSON_BACKUP_PATH)) fs.unlinkSync(JSON_BACKUP_PATH);
            seedInitialDataJson();
        }
        return true;
    }
};

// Initialize schema on load
db.init();

module.exports = db;
