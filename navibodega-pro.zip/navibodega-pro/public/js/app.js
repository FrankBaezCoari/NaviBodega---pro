// ============================================================
// NaviBodega Pro - Controlador Principal de Aplicación
// ============================================================

const App = {
    currentRoleView: 'client',

    init() {
        Auth.init();

        // Listen for session expiration
        window.onAuthExpired = () => {
            this.showToast('Su sesión ha caducado. Inicie sesión nuevamente.', 'warning');
            Auth.showAuthView();
        };
    },

    switchRoleView(role) {
        this.currentRoleView = role;
        const clientView = document.getElementById('view-client-portal');
        const adminView = document.getElementById('view-admin-portal');

        if (role === 'admin') {
            clientView.classList.add('hidden');
            adminView.classList.remove('hidden');
            Admin.init();
        } else {
            adminView.classList.add('hidden');
            clientView.classList.remove('hidden');
            Client.init();
        }
    },

    getStatusBadgeClass(status) {
        if (!status) return 'bg-slate-100 text-slate-600';
        if (status.includes('Pendiente')) return 'badge-status-pendiente';
        if (status.includes('Cotizado')) return 'badge-status-cotizado';
        if (status.includes('Aprobado')) return 'badge-status-aprobado';
        if (status.includes('Preparación') || status.includes('Embalaje')) return 'badge-status-preparacion';
        if (status.includes('Listo')) return 'badge-status-listo';
        if (status.includes('Entregado')) return 'badge-status-entregado';
        if (status.includes('Cancelado')) return 'badge-status-cancelado';
        return 'bg-slate-100 text-slate-700';
    },

    async viewOrderBreakdown(orderId) {
        try {
            const res = await API.getOrder(orderId);
            const o = res.order;
            if (!o) return;

            const modal = document.getElementById('modal-order-breakdown');
            document.getElementById('breakdown-title').textContent = `Detalle de Pedido ${o.id}`;
            document.getElementById('breakdown-vessel').textContent = o.vessel_name;
            document.getElementById('breakdown-captain').textContent = o.captain;
            document.getElementById('breakdown-departure').textContent = o.departure_date;
            document.getElementById('breakdown-status').textContent = o.status;
            document.getElementById('breakdown-status').className = `text-xs px-2.5 py-1 rounded-full font-bold ${this.getStatusBadgeClass(o.status)}`;

            const tbody = document.getElementById('breakdown-items-tbody');
            tbody.innerHTML = (o.items || []).map(it => `
                <tr class="border-b border-slate-100 text-xs">
                    <td class="py-2.5 px-3 font-semibold text-slate-800">${it.name}</td>
                    <td class="py-2.5 px-3 text-slate-500">${it.unit}</td>
                    <td class="py-2.5 px-3 text-center font-bold">${it.quantity}</td>
                    <td class="py-2.5 px-3 text-right">S/ ${Number(it.unit_price).toFixed(2)}</td>
                    <td class="py-2.5 px-3 text-right font-bold text-slate-900">S/ ${Number(it.subtotal).toFixed(2)}</td>
                </tr>
            `).join('');

            document.getElementById('breakdown-subtotal').textContent = `S/ ${Number(o.subtotal).toFixed(2)}`;
            document.getElementById('breakdown-fee').textContent = `S/ ${Number(o.delivery_fee).toFixed(2)}`;
            document.getElementById('breakdown-total').textContent = `S/ ${Number(o.total).toFixed(2)}`;

            document.getElementById('breakdown-notes').textContent = o.notes ? `"${o.notes}"` : 'Ninguna indicación especial.';
            document.getElementById('breakdown-admin-notes').textContent = o.admin_notes ? `"${o.admin_notes}"` : 'Sin notas de bodega.';

            modal.classList.remove('hidden');
        } catch (err) {
            this.showToast('Error al consultar pedido: ' + err.message, 'warning');
        }
    },

    closeOrderBreakdown() {
        document.getElementById('modal-order-breakdown')?.classList.add('hidden');
    },

    async printOrderManifest(orderId) {
        try {
            const res = await API.getOrder(orderId);
            const o = res.order;
            if (!o) return;

            const modal = document.getElementById('print-modal');
            document.getElementById('print-order-id').textContent = o.id;
            document.getElementById('print-date').textContent = new Date().toLocaleDateString('es-ES', { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' });
            document.getElementById('print-vessel-name').textContent = o.vessel_name;
            document.getElementById('print-captain').textContent = o.captain;
            document.getElementById('print-departure').textContent = o.departure_date;
            document.getElementById('print-client-company').textContent = o.client_name;

            const tbody = document.getElementById('print-items-tbody');
            tbody.innerHTML = (o.items || []).map((it, idx) => `
                <tr class="border-b border-slate-200 text-xs">
                    <td class="py-2 px-2 text-center text-slate-500">${idx + 1}</td>
                    <td class="py-2 px-2 font-bold text-slate-900">${it.name}</td>
                    <td class="py-2 px-2 text-slate-600">${it.category}</td>
                    <td class="py-2 px-2 text-slate-600">${it.unit}</td>
                    <td class="py-2 px-2 text-center font-bold text-slate-900">${it.quantity}</td>
                    <td class="py-2 px-2 text-right">S/ ${Number(it.unit_price).toFixed(2)}</td>
                    <td class="py-2 px-2 text-right font-black">S/ ${Number(it.subtotal).toFixed(2)}</td>
                </tr>
            `).join('');

            document.getElementById('print-subtotal').textContent = `S/ ${Number(o.subtotal).toFixed(2)}`;
            document.getElementById('print-fee').textContent = `S/ ${Number(o.delivery_fee).toFixed(2)}`;
            document.getElementById('print-total').textContent = `S/ ${Number(o.total).toFixed(2)}`;

            modal.classList.remove('hidden');
        } catch (err) {
            this.showToast('Error cargando guía de entrega: ' + err.message, 'warning');
        }
    },

    closePrintManifest() {
        document.getElementById('print-modal')?.classList.add('hidden');
    },

    triggerBrowserPrint() {
        window.print();
    },

    showToast(message, type = 'info') {
        const container = document.getElementById('toast-container');
        if (!container) return;

        const toast = document.createElement('div');
        let colorClasses = 'bg-slate-900 text-white border-slate-700';
        let icon = 'fa-info-circle text-sky-400';

        if (type === 'success') {
            colorClasses = 'bg-emerald-950 text-emerald-100 border-emerald-800';
            icon = 'fa-circle-check text-emerald-400';
        } else if (type === 'warning') {
            colorClasses = 'bg-amber-950 text-amber-100 border-amber-800';
            icon = 'fa-triangle-exclamation text-amber-400';
        }

        toast.className = `${colorClasses} border px-4 py-3 rounded-2xl shadow-2xl flex items-center space-x-3 text-xs font-semibold pointer-events-auto transition-all duration-300 transform translate-y-3 opacity-0`;
        toast.innerHTML = `
            <i class="fa-solid ${icon} text-base shrink-0"></i>
            <span class="leading-snug">${message}</span>
        `;

        container.appendChild(toast);

        setTimeout(() => {
            toast.classList.remove('translate-y-3', 'opacity-0');
        }, 10);

        setTimeout(() => {
            toast.classList.add('opacity-0', 'translate-y-3');
            setTimeout(() => toast.remove(), 300);
        }, 3800);
    }
};

window.App = App;

// Start on load
window.addEventListener('DOMContentLoaded', () => {
    App.init();
});
