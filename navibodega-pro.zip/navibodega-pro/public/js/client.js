// ============================================================
// NaviBodega Pro - Módulo de Cliente / Embarcación
// Moneda: Soles (S/)
// ============================================================

const Client = {
    products: [],
    cart: [],
    orders: [],
    activeCategory: 'all',
    searchQuery: '',

    async init() {
        this.loadCartFromStorage();
        await this.loadCatalog();
        await this.loadOrders();
        this.populateClientVesselDefaults();
    },

    populateClientVesselDefaults() {
        const u = Auth.currentUser;
        if (!u) return;

        const inputVessel = document.getElementById('client-order-vessel');
        const inputCaptain = document.getElementById('client-order-captain');

        if (inputVessel && !inputVessel.value) inputVessel.value = u.vessel_name || '';
        if (inputCaptain && !inputCaptain.value) inputCaptain.value = u.name || '';

        // Default departure date to tomorrow
        const depInput = document.getElementById('client-order-departure');
        if (depInput && !depInput.value) {
            const now = new Date();
            now.setDate(now.getDate() + 1);
            depInput.value = now.toISOString().slice(0, 16);
        }
    },

    loadCartFromStorage() {
        try {
            const raw = localStorage.getItem('navibodega_cart');
            this.cart = raw ? JSON.parse(raw) : [];
        } catch {
            this.cart = [];
        }
        this.renderCart();
    },

    saveCartToStorage() {
        localStorage.setItem('navibodega_cart', JSON.stringify(this.cart));
        this.renderCart();
        this.renderCatalog();
    },

    async loadCatalog() {
        try {
            const res = await API.getProducts();
            this.products = res.products || [];
            this.renderCatalog();
        } catch (err) {
            App.showToast('Error cargando catálogo: ' + err.message, 'warning');
        }
    },

    filterCategory(category) {
        this.activeCategory = category;
        document.querySelectorAll('.client-cat-pill').forEach(pill => {
            if (pill.dataset.cat === category) {
                pill.className = "client-cat-pill px-3.5 py-1.5 rounded-full text-xs font-bold bg-navy-800 text-white shadow";
            } else {
                pill.className = "client-cat-pill px-3.5 py-1.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-600 hover:bg-slate-200 transition";
            }
        });
        this.renderCatalog();
    },

    searchCatalog(query) {
        this.searchQuery = query.toLowerCase().trim();
        this.renderCatalog();
    },

    renderCatalog() {
        const grid = document.getElementById('client-catalog-grid');
        if (!grid) return;

        const filtered = this.products.filter(p => {
            const matchesCat = this.activeCategory === 'all' || p.category === this.activeCategory;
            const matchesSearch = !this.searchQuery || 
                p.name.toLowerCase().includes(this.searchQuery) || 
                p.category.toLowerCase().includes(this.searchQuery) ||
                (p.description && p.description.toLowerCase().includes(this.searchQuery));
            return matchesCat && matchesSearch;
        });

        if (filtered.length === 0) {
            grid.innerHTML = `
                <div class="col-span-full text-center py-12 text-slate-400 space-y-2">
                    <i class="fa-solid fa-box-open text-4xl text-slate-300"></i>
                    <p class="text-sm">No se encontraron productos con ese criterio.</p>
                </div>
            `;
            return;
        }

        grid.innerHTML = filtered.map(p => {
            const inCart = this.cart.find(c => c.productId === p.id);
            const cartQty = inCart ? inCart.quantity : 0;
            const isLowStock = p.stock <= p.min_stock;

            return `
            <div class="bg-white border border-slate-200 hover:border-navy-400 rounded-2xl p-4 transition-all shadow-sm hover:shadow flex flex-col justify-between">
                <div>
                    <!-- Category Badge & Unit -->
                    <div class="flex items-center justify-between gap-2 mb-2">
                        <span class="text-[10px] font-bold px-2 py-0.5 rounded-md bg-navy-50 text-navy-700 border border-navy-100">
                            ${p.category}
                        </span>
                        <span class="text-xs text-slate-500 font-medium">${p.unit}</span>
                    </div>

                    <!-- Name & Icon -->
                    <div class="flex items-start space-x-2.5">
                        <div class="w-8 h-8 rounded-lg bg-slate-100 text-navy-800 flex items-center justify-center shrink-0 text-sm mt-0.5">
                            <i class="fa-solid ${p.icon || 'fa-box'}"></i>
                        </div>
                        <div>
                            <h4 class="font-bold text-slate-800 text-sm leading-snug">${p.name}</h4>
                            <p class="text-[11px] text-slate-400 line-clamp-2 mt-0.5">${p.description || 'Suministro para consumo a bordo.'}</p>
                        </div>
                    </div>

                    <!-- Price Reference in Soles -->
                    <div class="mt-3 flex items-baseline space-x-1.5">
                        <span class="text-xs text-slate-400 font-medium">Precio ref:</span>
                        <span class="text-base font-extrabold text-slate-900">S/ ${Number(p.price).toFixed(2)}</span>
                        <span class="text-[11px] text-slate-400">/ ${p.unit}</span>
                    </div>
                </div>

                <!-- Footer Stock & Cart Actions -->
                <div class="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                    <div>
                        ${p.stock > 0 ? `
                            <span class="text-[11px] ${isLowStock ? 'text-amber-600 font-bold' : 'text-slate-400'}">
                                ${isLowStock ? '<i class="fa-solid fa-triangle-exclamation mr-1"></i>Stock bajo: ' : 'Stock: '}${p.stock}
                            </span>
                        ` : `
                            <span class="text-[11px] text-red-500 font-bold">Agotado</span>
                        `}
                    </div>

                    <div>
                        ${cartQty > 0 ? `
                            <div class="flex items-center space-x-1.5 bg-navy-50 border border-navy-200 rounded-lg p-1">
                                <button onclick="Client.updateCartQty('${p.id}', -1)" class="w-6 h-6 rounded bg-white text-navy-800 shadow-sm font-bold text-xs hover:bg-slate-100 flex items-center justify-center">-</button>
                                <span class="text-xs font-extrabold text-navy-950 px-1.5">${cartQty}</span>
                                <button onclick="Client.updateCartQty('${p.id}', 1)" class="w-6 h-6 rounded bg-navy-800 text-white shadow-sm font-bold text-xs hover:bg-navy-900 flex items-center justify-center">+</button>
                            </div>
                        ` : `
                            <button onclick="Client.addToCart('${p.id}')" ${p.stock <= 0 ? 'disabled' : ''} class="px-3 py-1.5 bg-navy-800 hover:bg-navy-900 disabled:opacity-50 text-white text-xs font-bold rounded-lg flex items-center space-x-1.5 shadow-sm transition">
                                <i class="fa-solid fa-plus text-[11px]"></i>
                                <span>Agregar</span>
                            </button>
                        `}
                    </div>
                </div>
            </div>
            `;
        }).join('');
    },

    addToCart(productId) {
        const prod = this.products.find(p => p.id === productId);
        if (!prod) return;

        const existing = this.cart.find(c => c.productId === productId);
        if (existing) {
            existing.quantity += 1;
        } else {
            this.cart.push({
                productId: prod.id,
                name: prod.name,
                category: prod.category,
                unit: prod.unit,
                unit_price: prod.price,
                quantity: 1
            });
        }
        this.saveCartToStorage();
        App.showToast(`"${prod.name}" añadido al pedido.`, 'success');
    },

    updateCartQty(productId, delta) {
        const idx = this.cart.findIndex(c => c.productId === productId);
        if (idx !== -1) {
            this.cart[idx].quantity += delta;
            if (this.cart[idx].quantity <= 0) {
                this.cart.splice(idx, 1);
            }
        }
        this.saveCartToStorage();
    },

    removeCartItem(productId) {
        this.cart = this.cart.filter(c => c.productId !== productId);
        this.saveCartToStorage();
    },

    clearCart() {
        if (this.cart.length > 0 && confirm('¿Desea vaciar la lista de pedidos?')) {
            this.cart = [];
            this.saveCartToStorage();
            App.showToast('Lista vaciada.', 'info');
        }
    },

    renderCart() {
        const container = document.getElementById('client-cart-items');
        const badgeCount = document.getElementById('nav-cart-count');
        const sideCount = document.getElementById('client-cart-count-side');
        const subtotalEl = document.getElementById('client-cart-subtotal');
        const feeEl = document.getElementById('client-cart-fee');
        const totalEl = document.getElementById('client-cart-total');

        const totalItemsCount = this.cart.reduce((sum, i) => sum + i.quantity, 0);
        if (badgeCount) badgeCount.textContent = totalItemsCount;
        if (sideCount) sideCount.textContent = `${this.cart.length} productos`;

        if (!container) return;

        if (this.cart.length === 0) {
            container.innerHTML = `
                <div class="text-center py-10 text-slate-400 space-y-2">
                    <i class="fa-solid fa-cart-shopping text-3xl text-slate-300"></i>
                    <p class="text-xs">No has agregado productos a la lista aún.</p>
                </div>
            `;
            if (subtotalEl) subtotalEl.textContent = 'S/ 0.00';
            if (feeEl) feeEl.textContent = 'S/ 0.00';
            if (totalEl) totalEl.textContent = 'S/ 0.00';
            return;
        }

        let subtotal = 0;
        container.innerHTML = this.cart.map(item => {
            const itemTotal = item.quantity * item.unit_price;
            subtotal += itemTotal;

            return `
            <div class="py-2.5 flex items-center justify-between text-xs border-b border-slate-100 last:border-none">
                <div class="pr-2 max-w-[170px]">
                    <p class="font-bold text-slate-800 truncate">${item.name}</p>
                    <p class="text-[11px] text-slate-400">${item.unit} &bull; S/ ${Number(item.unit_price).toFixed(2)}</p>
                </div>

                <div class="flex items-center space-x-2">
                    <div class="flex items-center space-x-1 bg-slate-100 rounded-md p-0.5 border border-slate-200">
                        <button onclick="Client.updateCartQty('${item.productId}', -1)" class="w-5 h-5 rounded bg-white text-slate-700 shadow-sm font-bold flex items-center justify-center hover:bg-slate-200">-</button>
                        <span class="text-xs font-bold px-1.5">${item.quantity}</span>
                        <button onclick="Client.updateCartQty('${item.productId}', 1)" class="w-5 h-5 rounded bg-navy-800 text-white shadow-sm font-bold flex items-center justify-center hover:bg-navy-900">+</button>
                    </div>
                    <span class="font-extrabold text-slate-800 text-xs w-16 text-right">S/ ${itemTotal.toFixed(2)}</span>
                    <button onclick="Client.removeCartItem('${item.productId}')" class="text-slate-300 hover:text-red-500 transition px-1">
                        <i class="fa-solid fa-trash-can"></i>
                    </button>
                </div>
            </div>
            `;
        }).join('');

        const deliveryFee = 15.00;
        const grandTotal = subtotal + deliveryFee;

        if (subtotalEl) subtotalEl.textContent = `S/ ${subtotal.toFixed(2)}`;
        if (feeEl) feeEl.textContent = `S/ ${deliveryFee.toFixed(2)}`;
        if (totalEl) totalEl.textContent = `S/ ${grandTotal.toFixed(2)}`;
    },

    async submitOrder() {
        const vesselName = document.getElementById('client-order-vessel').value.trim();
        const captain = document.getElementById('client-order-captain').value.trim();
        const departure = document.getElementById('client-order-departure').value;
        const notes = document.getElementById('client-order-notes').value.trim();
        const btn = document.getElementById('btn-submit-client-order');

        if (!vesselName || !captain || !departure) {
            App.showToast('Por favor completa el nombre de la embarcación, responsable y fecha de entrega.', 'warning');
            return;
        }

        if (this.cart.length === 0) {
            App.showToast('Tu lista está vacía. Añade productos desde el catálogo.', 'warning');
            return;
        }

        try {
            btn.disabled = true;
            btn.innerHTML = `<i class="fa-solid fa-spinner fa-spin mr-2"></i> Enviando Pedido...`;

            const orderData = {
                vessel_name: vesselName,
                captain,
                departure_date: departure,
                notes,
                delivery_fee: 15.00
            };

            const items = this.cart.map(c => ({
                product_id: c.productId,
                name: c.name,
                category: c.category,
                unit: c.unit,
                quantity: c.quantity,
                unit_price: c.unit_price
            }));

            const res = await API.createOrder(orderData, items);

            // Clear Cart
            this.cart = [];
            this.saveCartToStorage();
            document.getElementById('client-order-notes').value = '';

            App.showToast(`¡Pedido ${res.order.id} enviado exitosamente a la bodega!`, 'success');
            
            await this.loadOrders();
            this.switchClientTab('history');
        } catch (err) {
            App.showToast('Error al enviar pedido: ' + err.message, 'warning');
        } finally {
            btn.disabled = false;
            btn.innerHTML = `<i class="fa-solid fa-paper-plane mr-2"></i> Enviar Pedido a Bodega`;
        }
    },

    async loadOrders() {
        try {
            const res = await API.getOrders();
            this.orders = res.orders || [];
            this.renderOrders();
        } catch (err) {
            console.error('Error cargando pedidos:', err);
        }
    },

    renderOrders() {
        const container = document.getElementById('client-orders-container');
        const badgeTotal = document.getElementById('client-orders-badge-count');
        if (badgeTotal) badgeTotal.textContent = this.orders.length;

        if (!container) return;

        if (this.orders.length === 0) {
            container.innerHTML = `
                <div class="text-center py-16 bg-white rounded-2xl border border-slate-200 p-8 space-y-3">
                    <i class="fa-solid fa-receipt text-5xl text-slate-300"></i>
                    <h4 class="font-bold text-slate-700">Sin Pedidos Registrados</h4>
                    <p class="text-xs text-slate-400 max-w-md mx-auto">Aún no has emitido solicitudes de víveres. Usa la pestaña "Catálogo y Nuevo Pedido" para abastecer tu embarcación.</p>
                </div>
            `;
            return;
        }

        container.innerHTML = this.orders.map(o => {
            const statusClass = App.getStatusBadgeClass(o.status);
            const isQuoted = o.status.includes('Cotizado');
            const totalUnits = (o.items || []).reduce((s, i) => s + i.quantity, 0);

            return `
            <div class="bg-white border border-slate-200 hover:border-navy-300 rounded-2xl p-5 shadow-sm transition space-y-4">
                <!-- Top Header -->
                <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
                    <div class="flex items-center space-x-3">
                        <span class="font-black text-navy-950 text-base">${o.id}</span>
                        <span class="text-xs px-3 py-1 rounded-full font-bold ${statusClass}">
                            ${o.status}
                        </span>
                    </div>
                    <div class="flex items-center space-x-3 text-xs text-slate-400">
                        <span><i class="fa-regular fa-clock mr-1"></i>Fecha: ${o.created_at}</span>
                    </div>
                </div>

                <!-- Vessel Details (Simple: Embarcacion, Responsable, Fecha Zarpado) -->
                <div class="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                    <div>
                        <span class="text-slate-400 block font-medium">Embarcación</span>
                        <span class="font-bold text-slate-800 text-sm">${o.vessel_name}</span>
                    </div>
                    <div>
                        <span class="text-slate-400 block font-medium">Responsable / Capitán</span>
                        <span class="font-semibold text-slate-700">${o.captain}</span>
                    </div>
                    <div>
                        <span class="text-slate-400 block font-medium">Fecha Estimada de Zarpado</span>
                        <span class="font-bold text-red-600"><i class="fa-solid fa-calendar-day mr-1"></i>${o.departure_date}</span>
                    </div>
                </div>

                <!-- Items Preview -->
                <div class="bg-slate-50 p-3.5 rounded-xl border border-slate-100 space-y-2">
                    <div class="flex items-center justify-between text-xs font-semibold text-slate-600">
                        <span>Víveres y Productos Solicitados (${totalUnits} unidades)</span>
                    </div>
                    <div class="flex flex-wrap gap-1.5">
                        ${(o.items || []).map(it => `
                            <span class="bg-white border border-slate-200 text-slate-700 text-[11px] font-medium px-2 py-0.5 rounded-md">
                                ${it.quantity}x ${it.name}
                            </span>
                        `).join('')}
                    </div>
                    ${o.notes ? `
                        <p class="text-[11px] text-slate-500 italic pt-1"><i class="fa-solid fa-comment-dots mr-1 text-slate-400"></i>"${o.notes}"</p>
                    ` : ''}
                </div>

                <!-- Quotation Banner if Ready -->
                ${isQuoted ? `
                    <div class="bg-sky-50 border border-sky-200 rounded-xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-3">
                        <div class="space-y-1">
                            <span class="text-xs font-bold text-sky-900 flex items-center space-x-1.5">
                                <i class="fa-solid fa-file-invoice-dollar text-sky-600"></i>
                                <span>¡Cotización Lista para Aprobación!</span>
                            </span>
                            <p class="text-xs text-sky-700">La bodega ha cotizado tu pedido por un valor total de <b>S/ ${Number(o.total).toFixed(2)}</b>. Puedes aprobar la cotización para preparar la entrega.</p>
                            ${o.admin_notes ? `<p class="text-[11px] text-slate-600 mt-1"><b>Nota de Bodega:</b> ${o.admin_notes}</p>` : ''}
                        </div>
                        <div class="flex items-center space-x-2 shrink-0">
                            <button onclick="Client.approveQuote('${o.id}')" class="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow transition flex items-center space-x-1.5">
                                <i class="fa-solid fa-circle-check"></i>
                                <span>Aprobar Cotización (S/ ${Number(o.total).toFixed(2)})</span>
                            </button>
                        </div>
                    </div>
                ` : ''}

                <!-- Bottom Status & Actions -->
                <div class="pt-2 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                    <div class="flex items-center space-x-4">
                        <div>
                            <span class="text-slate-400 block">Total del Pedido:</span>
                            <span class="font-black text-base ${o.total > 0 ? 'text-emerald-700' : 'text-slate-400'}">
                                ${o.total > 0 ? 'S/ ' + Number(o.total).toFixed(2) : 'En revisión de bodega'}
                            </span>
                        </div>
                        ${o.admin_notes && !isQuoted ? `
                            <div class="bg-amber-50 text-amber-900 border border-amber-200 px-3 py-1.5 rounded-lg text-xs">
                                <b>Nota de Bodega:</b> ${o.admin_notes}
                            </div>
                        ` : ''}
                    </div>

                    <div class="flex items-center space-x-2">
                        <button onclick="App.viewOrderBreakdown('${o.id}')" class="px-3.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-lg flex items-center space-x-1 transition">
                            <i class="fa-solid fa-magnifying-glass"></i>
                            <span>Ver Detalle</span>
                        </button>
                        <button onclick="App.printOrderManifest('${o.id}')" class="px-3.5 py-1.5 bg-navy-800 hover:bg-navy-900 text-white font-semibold rounded-lg flex items-center space-x-1 transition shadow-sm">
                            <i class="fa-solid fa-print"></i>
                            <span>Guía de Entrega</span>
                        </button>
                    </div>
                </div>
            </div>
            `;
        }).join('');
    },

    async approveQuote(orderId) {
        if (!confirm(`¿Confirma la aprobación de la cotización para el pedido ${orderId}? Bodega preparará los productos inmediatamente.`)) {
            return;
        }

        try {
            await API.updateOrderStatus(orderId, 'Aprobado por Cliente', 'Cotización aprobada por el cliente. Proceder con el embalaje.');
            App.showToast(`¡Pedido ${orderId} aprobado exitosamente!`, 'success');
            await this.loadOrders();
        } catch (err) {
            App.showToast('Error al aprobar cotización: ' + err.message, 'warning');
        }
    },

    switchClientTab(tab) {
        const tabNew = document.getElementById('client-tab-new-order');
        const tabHistory = document.getElementById('client-tab-history');
        const btnNew = document.getElementById('tab-btn-client-new');
        const btnHistory = document.getElementById('tab-btn-client-history');

        if (tab === 'new-order') {
            tabNew.classList.remove('hidden');
            tabHistory.classList.add('hidden');
            btnNew.className = "pb-3 text-sm font-bold border-b-2 border-navy-700 text-navy-800 flex items-center space-x-2";
            btnHistory.className = "pb-3 text-sm font-semibold border-b-2 border-transparent text-slate-500 hover:text-slate-700 flex items-center space-x-2";
        } else {
            tabNew.classList.add('hidden');
            tabHistory.classList.remove('hidden');
            btnHistory.className = "pb-3 text-sm font-bold border-b-2 border-navy-700 text-navy-800 flex items-center space-x-2";
            btnNew.className = "pb-3 text-sm font-semibold border-b-2 border-transparent text-slate-500 hover:text-slate-700 flex items-center space-x-2";
            this.loadOrders();
        }
    }
};

window.Client = Client;
