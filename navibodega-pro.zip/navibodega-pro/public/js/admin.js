// ============================================================
// NaviBodega Pro - Módulo de Administración de Bodega
// Moneda: Soles (S/)
// ============================================================

const Admin = {
    orders: [],
    products: [],
    users: [],
    stats: null,
    statusFilter: 'all',
    activeQuotingOrder: null,

    async init() {
        await Promise.all([
            this.loadStats(),
            this.loadOrders(),
            this.loadProducts(),
            this.loadUsers()
        ]);
    },

    async loadStats() {
        try {
            const res = await API.getStats();
            this.stats = res.stats;
            this.renderKPIs();
        } catch (err) {
            console.error('Error cargando KPIs:', err);
        }
    },

    renderKPIs() {
        if (!this.stats) return;

        const kpiPending = document.getElementById('kpi-pending-count');
        const kpiQuoted = document.getElementById('kpi-quoted-count');
        const kpiInPrep = document.getElementById('kpi-prep-count');
        const kpiCompleted = document.getElementById('kpi-completed-count');
        const kpiRevenue = document.getElementById('kpi-revenue-total');
        const kpiStockAlerts = document.getElementById('kpi-stock-alerts');

        if (kpiPending) kpiPending.textContent = this.stats.pendingQuotes;
        if (kpiQuoted) kpiQuoted.textContent = this.stats.quotedOrders;
        if (kpiInPrep) kpiInPrep.textContent = this.stats.inPreparation;
        if (kpiCompleted) kpiCompleted.textContent = this.stats.completedOrders;
        if (kpiRevenue) kpiRevenue.textContent = `S/ ${Number(this.stats.totalRevenue).toLocaleString('es-PE', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
        if (kpiStockAlerts) kpiStockAlerts.textContent = this.stats.lowStockAlerts;

        // Top navbar alert badge
        const navAlert = document.getElementById('admin-nav-pending-badge');
        if (navAlert) {
            if (this.stats.pendingQuotes > 0) {
                navAlert.textContent = `${this.stats.pendingQuotes} pendientes`;
                navAlert.classList.remove('hidden');
            } else {
                navAlert.classList.add('hidden');
            }
        }
    },

    async loadOrders() {
        try {
            const res = await API.getOrders();
            this.orders = res.orders || [];
            this.renderOrders();
        } catch (err) {
            App.showToast('Error cargando pedidos en administración: ' + err.message, 'warning');
        }
    },

    filterOrdersByStatus(status) {
        this.statusFilter = status;
        document.querySelectorAll('.admin-filter-pill').forEach(pill => {
            if (pill.dataset.status === status) {
                pill.className = "admin-filter-pill px-3 py-1.5 rounded-xl text-xs font-bold bg-navy-800 text-white shadow";
            } else {
                pill.className = "admin-filter-pill px-3 py-1.5 rounded-xl text-xs font-semibold bg-slate-100 text-slate-600 hover:bg-slate-200 transition";
            }
        });
        this.renderOrders();
    },

    renderOrders() {
        const container = document.getElementById('admin-orders-list');
        const searchVal = (document.getElementById('admin-order-search')?.value || '').toLowerCase().trim();

        if (!container) return;

        const filtered = this.orders.filter(o => {
            const matchesStatus = this.statusFilter === 'all' || o.status === this.statusFilter;
            const matchesSearch = !searchVal || 
                o.id.toLowerCase().includes(searchVal) || 
                o.vessel_name.toLowerCase().includes(searchVal) ||
                o.captain.toLowerCase().includes(searchVal);
            return matchesStatus && matchesSearch;
        });

        if (filtered.length === 0) {
            container.innerHTML = `
                <div class="text-center py-16 bg-white rounded-2xl border border-slate-200 p-8 space-y-3">
                    <i class="fa-solid fa-clipboard-check text-5xl text-slate-300"></i>
                    <h4 class="font-bold text-slate-700">No se encontraron pedidos</h4>
                    <p class="text-xs text-slate-400">No hay registros coincidentes con los filtros aplicados.</p>
                </div>
            `;
            return;
        }

        container.innerHTML = filtered.map(o => {
            const statusClass = App.getStatusBadgeClass(o.status);
            const totalItemsCount = (o.items || []).reduce((s, i) => s + i.quantity, 0);

            return `
            <div class="bg-white border border-slate-200 hover:border-navy-300 rounded-2xl p-5 shadow-sm transition space-y-4">
                <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
                    <div class="flex items-center space-x-3">
                        <span class="font-black text-navy-950 text-base">${o.id}</span>
                        <span class="text-xs px-3 py-1 rounded-full font-bold ${statusClass}">
                            ${o.status}
                        </span>
                    </div>
                    <div class="flex items-center space-x-4 text-xs text-slate-500">
                        <span><i class="fa-solid fa-ship text-navy-600 mr-1.5"></i>${o.vessel_name}</span>
                        <span><i class="fa-regular fa-clock mr-1"></i>${o.created_at}</span>
                    </div>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                    <div>
                        <span class="text-slate-400 block font-medium">Cliente / Responsable</span>
                        <span class="font-bold text-slate-800">${o.client_name}</span>
                        <span class="text-[11px] text-slate-400">${o.client_email}</span>
                    </div>
                    <div>
                        <span class="text-slate-400 block font-medium">Embarcación</span>
                        <span class="font-semibold text-slate-700">${o.vessel_name}</span>
                    </div>
                    <div>
                        <span class="text-slate-400 block font-medium">Fecha Estimada de Zarpado</span>
                        <span class="font-bold text-red-600"><i class="fa-solid fa-calendar-day mr-1"></i>${o.departure_date}</span>
                    </div>
                </div>

                <!-- Products Summary -->
                <div class="bg-slate-50 p-3 rounded-xl border border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
                    <div class="space-y-1">
                        <span class="font-bold text-slate-700">${(o.items || []).length} ítems &bull; ${totalItemsCount} unidades</span>
                        <div class="flex flex-wrap gap-1 mt-1">
                            ${(o.items || []).slice(0, 4).map(it => `
                                <span class="bg-white border border-slate-200 text-slate-600 text-[10px] px-1.5 py-0.5 rounded">
                                    ${it.quantity}x ${it.name}
                                </span>
                            `).join('')}
                            ${(o.items || []).length > 4 ? `
                                <span class="text-slate-400 text-[10px] font-bold self-center">+${(o.items || []).length - 4} más</span>
                            ` : ''}
                        </div>
                        ${o.notes ? `<p class="text-[11px] text-slate-500 italic pt-1"><i class="fa-solid fa-comment-dots text-slate-400 mr-1"></i>"${o.notes}"</p>` : ''}
                    </div>

                    <div class="text-right shrink-0">
                        <span class="text-slate-400 block text-[11px]">Valor Total Estimado:</span>
                        <span class="font-black text-base text-emerald-700">S/ ${Number(o.total || 0).toFixed(2)}</span>
                    </div>
                </div>

                <!-- Action Controls -->
                <div class="pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2">
                    <div class="text-xs text-slate-400">
                        ${o.admin_notes ? `<span class="text-amber-800 bg-amber-50 border border-amber-200 px-2.5 py-1 rounded-md text-[11px]"><b>Nota Bodega:</b> ${o.admin_notes}</span>` : ''}
                    </div>
                    <div class="flex items-center space-x-2">
                        <button onclick="Admin.openQuoteModal('${o.id}')" class="px-3.5 py-1.5 bg-navy-800 hover:bg-navy-900 text-white font-bold text-xs rounded-xl shadow-sm transition flex items-center space-x-1.5">
                            <i class="fa-solid fa-sliders"></i>
                            <span>Gestionar / Cotizar Pedido</span>
                        </button>
                        <button onclick="App.printOrderManifest('${o.id}')" class="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs rounded-xl transition flex items-center space-x-1">
                            <i class="fa-solid fa-print"></i>
                            <span>Guía de Entrega</span>
                        </button>
                    </div>
                </div>
            </div>
            `;
        }).join('');
    },

    openQuoteModal(orderId) {
        const order = this.orders.find(o => o.id === orderId);
        if (!order) return;

        // Clone order state for quoting
        this.activeQuotingOrder = JSON.parse(JSON.stringify(order));
        const modal = document.getElementById('modal-quote-inspector');
        if (!modal) return;

        document.getElementById('modal-quote-order-id').textContent = order.id;
        document.getElementById('modal-quote-vessel').textContent = order.vessel_name;
        document.getElementById('modal-quote-captain').textContent = order.captain;
        document.getElementById('modal-quote-departure').textContent = order.departure_date;
        document.getElementById('modal-quote-client-notes').textContent = order.notes || 'Sin instrucciones adicionales.';

        // Render Items editable table
        this.renderQuoteItemsTable();

        // Status Select
        document.getElementById('modal-quote-status-select').value = order.status;
        document.getElementById('modal-quote-admin-notes').value = order.admin_notes || '';
        document.getElementById('modal-quote-delivery-fee').value = Number(order.delivery_fee || 35).toFixed(2);

        this.calculateModalTotals();

        modal.classList.remove('hidden');
    },

    renderQuoteItemsTable() {
        const tbody = document.getElementById('modal-quote-items-tbody');
        if (!tbody || !this.activeQuotingOrder) return;

        tbody.innerHTML = (this.activeQuotingOrder.items || []).map((item, idx) => {
            const subtotal = item.quantity * item.unit_price;

            return `
            <tr class="border-b border-slate-100 hover:bg-slate-50 text-xs">
                <td class="py-2.5 px-3">
                    <p class="font-bold text-slate-800 leading-tight">${item.name}</p>
                    <span class="text-[10px] text-slate-400">${item.category}</span>
                </td>
                <td class="py-2.5 px-3 text-slate-500">${item.unit}</td>
                <td class="py-2.5 px-3 text-center font-bold text-slate-800">${item.quantity}</td>
                <td class="py-2.5 px-3">
                    <div class="flex items-center space-x-1">
                        <span class="text-slate-400 font-bold">S/</span>
                        <input type="number" step="0.01" min="0" value="${Number(item.unit_price).toFixed(2)}" 
                            onchange="Admin.updateQuotingItemPrice(${idx}, this.value)" 
                            class="w-20 border border-slate-300 rounded px-1.5 py-1 text-xs font-bold text-slate-800 focus:ring-1 focus:ring-navy-600 outline-none">
                    </div>
                </td>
                <td class="py-2.5 px-3 text-right font-black text-slate-800" id="item-subtotal-${idx}">
                    S/ ${subtotal.toFixed(2)}
                </td>
            </tr>
            `;
        }).join('');
    },

    updateQuotingItemPrice(index, newPrice) {
        if (!this.activeQuotingOrder || !this.activeQuotingOrder.items[index]) return;
        const price = Math.max(0, parseFloat(newPrice) || 0);
        this.activeQuotingOrder.items[index].unit_price = price;

        const subtotal = this.activeQuotingOrder.items[index].quantity * price;
        const subtotalEl = document.getElementById(`item-subtotal-${index}`);
        if (subtotalEl) subtotalEl.textContent = `S/ ${subtotal.toFixed(2)}`;

        this.calculateModalTotals();
    },

    calculateModalTotals() {
        if (!this.activeQuotingOrder) return;

        const subtotal = this.activeQuotingOrder.items.reduce((s, i) => s + (i.quantity * i.unit_price), 0);
        const deliveryFee = parseFloat(document.getElementById('modal-quote-delivery-fee')?.value) || 0;
        const total = subtotal + deliveryFee;

        this.activeQuotingOrder.subtotal = subtotal;
        this.activeQuotingOrder.delivery_fee = deliveryFee;
        this.activeQuotingOrder.total = total;

        const elSubtotal = document.getElementById('modal-quote-subtotal');
        const elTotal = document.getElementById('modal-quote-grand-total');

        if (elSubtotal) elSubtotal.textContent = `S/ ${subtotal.toFixed(2)}`;
        if (elTotal) elTotal.textContent = `S/ ${total.toFixed(2)}`;
    },

    async saveQuoteChanges() {
        if (!this.activeQuotingOrder) return;
        const btn = document.getElementById('btn-save-quote-modal');
        const status = document.getElementById('modal-quote-status-select').value;
        const adminNotes = document.getElementById('modal-quote-admin-notes').value.trim();
        const deliveryFee = parseFloat(document.getElementById('modal-quote-delivery-fee').value) || 0;

        try {
            btn.disabled = true;
            btn.innerHTML = `<i class="fa-solid fa-spinner fa-spin mr-2"></i> Guardando...`;

            await API.updateOrderQuote(this.activeQuotingOrder.id, {
                items: this.activeQuotingOrder.items,
                delivery_fee: deliveryFee,
                admin_notes: adminNotes,
                status
            });

            App.showToast(`Cotización de pedido ${this.activeQuotingOrder.id} guardada correctamente.`, 'success');
            this.closeQuoteModal();
            await Promise.all([this.loadOrders(), this.loadStats()]);
        } catch (err) {
            App.showToast('Error al guardar cotización: ' + err.message, 'warning');
        } finally {
            btn.disabled = false;
            btn.innerHTML = `<i class="fa-solid fa-floppy-disk mr-2"></i> Guardar Cambios`;
        }
    },

    closeQuoteModal() {
        document.getElementById('modal-quote-inspector')?.classList.add('hidden');
        this.activeQuotingOrder = null;
    },

    // INVENTORY MANAGEMENT
    async loadProducts() {
        try {
            const res = await API.getProducts();
            this.products = res.products || [];
            this.renderInventoryTable();
        } catch (err) {
            console.error('Error cargando productos:', err);
        }
    },

    renderInventoryTable() {
        const tbody = document.getElementById('inventory-table-tbody');
        const searchVal = (document.getElementById('inventory-search')?.value || '').toLowerCase().trim();
        if (!tbody) return;

        const filtered = this.products.filter(p => {
            return !searchVal || 
                p.name.toLowerCase().includes(searchVal) || 
                p.category.toLowerCase().includes(searchVal);
        });

        tbody.innerHTML = filtered.map(p => {
            const isLowStock = p.stock <= p.min_stock;

            return `
            <tr class="border-b border-slate-100 hover:bg-slate-50 text-xs">
                <td class="py-2.5 px-3">
                    <p class="font-bold text-slate-800 leading-tight">${p.name}</p>
                    <span class="text-[10px] text-slate-400">${p.id}</span>
                </td>
                <td class="py-2.5 px-3">
                    <span class="bg-slate-100 text-slate-700 text-[10px] font-semibold px-2 py-0.5 rounded">
                        ${p.category}
                    </span>
                </td>
                <td class="py-2.5 px-3 text-slate-500">${p.unit}</td>
                <td class="py-2.5 px-3">
                    <div class="flex items-center space-x-1">
                        <input type="number" min="0" value="${p.stock}" 
                            onchange="Admin.saveProductStock('${p.id}', this.value)" 
                            class="w-16 border ${isLowStock ? 'border-amber-400 bg-amber-50 font-black text-amber-900' : 'border-slate-300'} rounded px-1.5 py-0.5 text-xs text-center font-bold outline-none">
                    </div>
                </td>
                <td class="py-2.5 px-3">
                    <div class="flex items-center space-x-1">
                        <span class="text-slate-400 font-bold">S/</span>
                        <input type="number" step="0.01" min="0" value="${Number(p.price).toFixed(2)}" 
                            onchange="Admin.saveProductPrice('${p.id}', this.value)" 
                            class="w-20 border border-slate-300 rounded px-1.5 py-0.5 text-xs font-bold text-slate-800 outline-none">
                    </div>
                </td>
                <td class="py-2.5 px-3 text-right">
                    <button onclick="Admin.deleteProduct('${p.id}')" class="text-slate-300 hover:text-red-500 transition px-2 py-1">
                        <i class="fa-solid fa-trash-can"></i>
                    </button>
                </td>
            </tr>
            `;
        }).join('');
    },

    async saveProductStock(id, newStock) {
        const stock = parseInt(newStock) || 0;
        try {
            const prod = this.products.find(p => p.id === id);
            if (!prod) return;
            await API.updateProduct(id, { ...prod, stock });
            prod.stock = stock;
            App.showToast(`Stock de "${prod.name}" actualizado a ${stock} unid.`, 'success');
            await this.loadStats();
        } catch (err) {
            App.showToast('Error al actualizar stock: ' + err.message, 'warning');
        }
    },

    async saveProductPrice(id, newPrice) {
        const price = parseFloat(newPrice) || 0;
        try {
            const prod = this.products.find(p => p.id === id);
            if (!prod) return;
            await API.updateProduct(id, { ...prod, price });
            prod.price = price;
            App.showToast(`Precio de "${prod.name}" actualizado a S/ ${price.toFixed(2)}`, 'success');
        } catch (err) {
            App.showToast('Error al actualizar precio: ' + err.message, 'warning');
        }
    },

    async addNewProduct(e) {
        e.preventDefault();
        const name = document.getElementById('new-item-name').value.trim();
        const category = document.getElementById('new-item-cat').value;
        const unit = document.getElementById('new-item-unit').value.trim();
        const price = parseFloat(document.getElementById('new-item-price').value) || 0;
        const stock = parseInt(document.getElementById('new-item-stock').value) || 10;
        const desc = document.getElementById('new-item-desc').value.trim();

        if (!name || !unit || price <= 0) {
            App.showToast('Complete el nombre, unidad y precio mayor a 0.', 'warning');
            return;
        }

        try {
            await API.createProduct({
                name,
                category,
                unit,
                price,
                stock,
                min_stock: 10,
                description: desc
            });

            App.showToast(`Producto "${name}" agregado al inventario.`, 'success');
            document.getElementById('form-add-product').reset();
            await this.loadProducts();
            await this.loadStats();
        } catch (err) {
            App.showToast('Error al añadir producto: ' + err.message, 'warning');
        }
    },

    async deleteProduct(id) {
        const prod = this.products.find(p => p.id === id);
        if (!confirm(`¿Desea dar de baja el producto "${prod ? prod.name : id}" de la bodega?`)) return;

        try {
            await API.deleteProduct(id);
            App.showToast('Producto removido del inventario.', 'info');
            await this.loadProducts();
            await this.loadStats();
        } catch (err) {
            App.showToast('Error al eliminar producto: ' + err.message, 'warning');
        }
    },

    openInventoryModal() {
        this.renderInventoryTable();
        document.getElementById('modal-inventory-manager')?.classList.remove('hidden');
    },

    closeInventoryModal() {
        document.getElementById('modal-inventory-manager')?.classList.add('hidden');
    },

    // USERS LIST
    async loadUsers() {
        try {
            const res = await API.getUsers();
            this.users = res.users || [];
            this.renderUsers();
        } catch (err) {
            console.error('Error cargando clientes:', err);
        }
    },

    renderUsers() {
        const container = document.getElementById('admin-users-tbody');
        if (!container) return;

        container.innerHTML = this.users.map(u => `
            <tr class="border-b border-slate-100 hover:bg-slate-50 text-xs">
                <td class="py-2.5 px-3">
                    <p class="font-bold text-slate-800">${u.name}</p>
                    <span class="text-[11px] text-slate-400">${u.email}</span>
                </td>
                <td class="py-2.5 px-3">
                    <span class="px-2 py-0.5 rounded text-[10px] font-bold ${u.role === 'admin' ? 'bg-amber-100 text-amber-900' : 'bg-sky-100 text-sky-900'}">
                        ${u.role.toUpperCase()}
                    </span>
                </td>
                <td class="py-2.5 px-3 font-semibold text-slate-700">${u.vessel_name || '-'}</td>
                <td class="py-2.5 px-3 text-slate-500">${u.company || '-'}</td>
                <td class="py-2.5 px-3 text-slate-500">${u.phone || '-'}</td>
                <td class="py-2.5 px-3 text-slate-400 text-right">${u.created_at ? u.created_at.slice(0, 10) : '-'}</td>
            </tr>
        `).join('');
    },

    async resetDemoDatabase() {
        if (!confirm('¿Desea restablecer la base de datos a sus valores iniciales de demostración? Se reiniciarán pedidos e inventario.')) {
            return;
        }

        try {
            await API.resetDatabase();
            App.showToast('Base de datos restablecida con datos de demostración.', 'success');
            await this.init();
        } catch (err) {
            App.showToast('Error al restablecer base de datos: ' + err.message, 'warning');
        }
    }
};

window.Admin = Admin;
