// ============================================================
// NaviBodega Pro - Cliente de API REST
// ============================================================

const API = {
    BASE_URL: '', // Same origin

    getToken() {
        return localStorage.getItem('navibodega_token') || null;
    },

    setToken(token) {
        if (token) {
            localStorage.setItem('navibodega_token', token);
        } else {
            localStorage.removeItem('navibodega_token');
        }
    },

    getUser() {
        try {
            const raw = localStorage.getItem('navibodega_user');
            return raw ? JSON.parse(raw) : null;
        } catch {
            return null;
        }
    },

    setUser(user) {
        if (user) {
            localStorage.setItem('navibodega_user', JSON.stringify(user));
        } else {
            localStorage.removeItem('navibodega_user');
        }
    },

    clearAuth() {
        localStorage.removeItem('navibodega_token');
        localStorage.removeItem('navibodega_user');
    },

    async request(endpoint, options = {}) {
        const headers = {
            'Content-Type': 'application/json',
            ...(options.headers || {})
        };

        const token = this.getToken();
        if (token) {
            headers['Authorization'] = `Bearer ${token}`;
        }

        try {
            const res = await fetch(`${this.BASE_URL}${endpoint}`, {
                ...options,
                headers
            });

            const data = await res.json().catch(() => ({}));

            if (!res.ok) {
                if (res.status === 401) {
                    this.clearAuth();
                    if (window.onAuthExpired) {
                        window.onAuthExpired();
                    }
                }
                const msg = data.error || `Error ${res.status}: ${res.statusText}`;
                throw new Error(msg);
            }

            return data;
        } catch (err) {
            console.error(`[API Error] ${endpoint}:`, err);
            throw err;
        }
    },

    // AUTH
    async login(email, password) {
        const data = await this.request('/api/auth/login', {
            method: 'POST',
            body: JSON.stringify({ email, password })
        });
        if (data.token) {
            this.setToken(data.token);
            this.setUser(data.user);
        }
        return data;
    },

    async register(userData) {
        const data = await this.request('/api/auth/register', {
            method: 'POST',
            body: JSON.stringify(userData)
        });
        if (data.token) {
            this.setToken(data.token);
            this.setUser(data.user);
        }
        return data;
    },

    async getMe() {
        return this.request('/api/auth/me');
    },

    // PRODUCTS
    async getProducts() {
        return this.request('/api/products');
    },

    async createProduct(product) {
        return this.request('/api/products', {
            method: 'POST',
            body: JSON.stringify(product)
        });
    },

    async updateProduct(id, product) {
        return this.request(`/api/products/${encodeURIComponent(id)}`, {
            method: 'PUT',
            body: JSON.stringify(product)
        });
    },

    async deleteProduct(id) {
        return this.request(`/api/products/${encodeURIComponent(id)}`, {
            method: 'DELETE'
        });
    },

    // ORDERS
    async getOrders() {
        return this.request('/api/orders');
    },

    async getOrder(id) {
        return this.request(`/api/orders/${encodeURIComponent(id)}`);
    },

    async createOrder(orderData, items) {
        return this.request('/api/orders', {
            method: 'POST',
            body: JSON.stringify({ ...orderData, items })
        });
    },

    async updateOrderStatus(id, status, notes = null) {
        return this.request(`/api/orders/${encodeURIComponent(id)}/status`, {
            method: 'PATCH',
            body: JSON.stringify({ status, notes })
        });
    },

    async updateOrderQuote(id, quoteData) {
        return this.request(`/api/orders/${encodeURIComponent(id)}/quote`, {
            method: 'PUT',
            body: JSON.stringify(quoteData)
        });
    },

    // ADMIN
    async getStats() {
        return this.request('/api/stats');
    },

    async getUsers() {
        return this.request('/api/users');
    },

    async resetDatabase() {
        return this.request('/api/admin/reset', {
            method: 'POST'
        });
    }
};

window.API = API;
