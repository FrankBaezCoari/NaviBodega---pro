// ============================================================
// NaviBodega Pro - Gestión de Autenticación & Sesión
// ============================================================

const Auth = {
    currentUser: null,

    init() {
        this.currentUser = API.getUser();
        this.bindEvents();
        this.checkSession();
    },

    bindEvents() {
        // Login form
        const loginForm = document.getElementById('form-login');
        if (loginForm) {
            loginForm.addEventListener('submit', e => this.handleLogin(e));
        }

        // Register form
        const regForm = document.getElementById('form-register');
        if (regForm) {
            regForm.addEventListener('submit', e => this.handleRegister(e));
        }
    },

    switchAuthTab(tab) {
        const tabLogin = document.getElementById('auth-tab-login');
        const tabRegister = document.getElementById('auth-tab-register');
        const btnLogin = document.getElementById('btn-auth-tab-login');
        const btnRegister = document.getElementById('btn-auth-tab-register');

        if (tab === 'login') {
            tabLogin.classList.remove('hidden');
            tabRegister.classList.add('hidden');
            btnLogin.className = "flex-1 py-2.5 text-center text-xs font-bold rounded-lg bg-navy-800 text-white shadow";
            btnRegister.className = "flex-1 py-2.5 text-center text-xs font-bold rounded-lg text-slate-400 hover:text-white transition";
        } else {
            tabLogin.classList.add('hidden');
            tabRegister.classList.remove('hidden');
            btnRegister.className = "flex-1 py-2.5 text-center text-xs font-bold rounded-lg bg-navy-800 text-white shadow";
            btnLogin.className = "flex-1 py-2.5 text-center text-xs font-bold rounded-lg text-slate-400 hover:text-white transition";
        }
    },

    async checkSession() {
        const token = API.getToken();
        if (!token) {
            this.showAuthView();
            return;
        }

        try {
            const data = await API.getMe();
            this.currentUser = data.user;
            API.setUser(data.user);
            this.showAppView();
        } catch (err) {
            console.warn('[Auth] Token inválido o expirado');
            API.clearAuth();
            this.showAuthView();
        }
    },

    async handleLogin(e) {
        e.preventDefault();
        const email = document.getElementById('login-email').value.trim();
        const password = document.getElementById('login-password').value;
        const btn = document.getElementById('btn-submit-login');

        if (!email || !password) {
            App.showToast('Por favor ingrese su correo y contraseña.', 'warning');
            return;
        }

        try {
            btn.disabled = true;
            btn.innerHTML = `<i class="fa-solid fa-spinner fa-spin mr-2"></i> Verificando...`;

            const res = await API.login(email, password);
            this.currentUser = res.user;

            App.showToast(`¡Bienvenido a bordo, ${res.user.name}!`, 'success');
            this.showAppView();
        } catch (err) {
            App.showToast(err.message, 'warning');
        } finally {
            btn.disabled = false;
            btn.innerHTML = `<i class="fa-solid fa-right-to-bracket mr-2"></i> Iniciar Sesión en el Puerto`;
        }
    },

    async handleRegister(e) {
        e.preventDefault();
        const name = document.getElementById('reg-name').value.trim();
        const email = document.getElementById('reg-email').value.trim();
        const password = document.getElementById('reg-password').value;
        const confirmPass = document.getElementById('reg-confirm-password').value;
        const company = document.getElementById('reg-company') ? document.getElementById('reg-company').value.trim() : '';
        const vesselName = document.getElementById('reg-vessel') ? document.getElementById('reg-vessel').value.trim() : '';
        const phone = document.getElementById('reg-phone') ? document.getElementById('reg-phone').value.trim() : '';
        const btn = document.getElementById('btn-submit-register');

        if (!name || !email || !password) {
            App.showToast('Por favor complete los campos obligatorios.', 'warning');
            return;
        }

        if (password !== confirmPass) {
            App.showToast('Las contraseñas no coinciden.', 'warning');
            return;
        }

        if (password.length < 6) {
            App.showToast('La contraseña debe tener mínimo 6 caracteres.', 'warning');
            return;
        }

        try {
            btn.disabled = true;
            btn.innerHTML = `<i class="fa-solid fa-spinner fa-spin mr-2"></i> Creando Cuenta...`;

            const res = await API.register({
                name,
                email,
                password,
                company,
                vessel_name: vesselName,
                phone
            });

            this.currentUser = res.user;
            App.showToast('¡Cuenta creada con éxito! Bienvenido al sistema.', 'success');
            this.showAppView();
        } catch (err) {
            App.showToast(err.message, 'warning');
        } finally {
            btn.disabled = false;
            btn.innerHTML = `<i class="fa-solid fa-user-plus mr-2"></i> Registrar Cuenta de Cliente`;
        }
    },

    quickDemoLogin(role) {
        if (role === 'admin') {
            document.getElementById('login-email').value = 'admin@navibodega.com';
            document.getElementById('login-password').value = 'admin123';
        } else {
            document.getElementById('login-email').value = 'capitan@pesquero.com';
            document.getElementById('login-password').value = 'cliente123';
        }
        document.getElementById('form-login').dispatchEvent(new Event('submit'));
    },

    logout() {
        if (confirm('¿Desea cerrar la sesión naval actual?')) {
            API.clearAuth();
            this.currentUser = null;
            App.showToast('Sesión cerrada correctamente.', 'info');
            this.showAuthView();
        }
    },

    showAuthView() {
        document.getElementById('view-auth').classList.remove('hidden');
        document.getElementById('view-app-main').classList.add('hidden');
        document.getElementById('top-nav-bar').classList.add('hidden');
    },

    showAppView() {
        document.getElementById('view-auth').classList.add('hidden');
        document.getElementById('view-app-main').classList.remove('hidden');
        document.getElementById('top-nav-bar').classList.remove('hidden');

        // Update Nav User Badge
        this.renderUserBadge();

        // Switch to appropriate view based on role
        if (this.currentUser.role === 'admin') {
            App.switchRoleView('admin');
        } else {
            App.switchRoleView('client');
        }
    },

    renderUserBadge() {
        const u = this.currentUser;
        if (!u) return;

        document.getElementById('nav-user-name').textContent = u.name;
        const roleBadge = document.getElementById('nav-user-role-badge');

        if (u.role === 'admin') {
            roleBadge.textContent = 'ADMINISTRADOR BODEGA';
            roleBadge.className = 'text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-amber-400 text-slate-950 uppercase tracking-wider';
            document.getElementById('nav-vessel-info').textContent = 'Base Central de Operaciones';
        } else {
            roleBadge.textContent = 'CLIENTE NAVAL';
            roleBadge.className = 'text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-sky-400 text-navy-950 uppercase tracking-wider';
            document.getElementById('nav-vessel-info').textContent = u.vessel_name || 'Buque Comercial';
        }
    }
};

window.Auth = Auth;
