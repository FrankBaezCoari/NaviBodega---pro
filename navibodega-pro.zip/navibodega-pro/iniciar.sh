#!/usr/bin/env bash
echo "======================================================================"
echo "   NAVIBODEGA PRO - SISTEMA DE AVITUALLAMIENTO MARITIMO V2.0"
echo "======================================================================"
echo ""

if ! command -v node &> /dev/null; then
    echo "[ERROR] Node.js no está instalado."
    echo "Por favor instale Node.js desde https://nodejs.org"
    exit 1
fi

echo "[1/2] Iniciando Servidor Portuario..."
echo "Abra en su navegador: http://localhost:3000"
echo ""

if command -v xdg-open &> /dev/null; then
    xdg-open http://localhost:3000 &
elif command -v open &> /dev/null; then
    open http://localhost:3000 &
fi

node server.js
