@echo off
title NaviBodega Pro - Sistema de Avituallamiento Maritimo
color 0B

echo ======================================================================
echo    NAVIBODEGA PRO - SISTEMA DE AVITUALLAMIENTO MARITIMO V2.0
echo ======================================================================
echo.

where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] No se detecto Node.js instalado en su sistema.
    echo Por favor instale Node.js desde https://nodejs.org para ejecutar el servidor.
    echo.
    pause
    exit /b
)

echo [1/2] Iniciando Servidor Portuario...
echo.
echo Presione Ctrl + C en cualquier momento para detener el servidor.
echo.

start "" http://localhost:3000
node server.js

pause
