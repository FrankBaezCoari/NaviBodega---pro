// ============================================================
// NaviBodega Pro - Servidor HTTP & API REST Profesional
// Sin dependencias externas obligatorias - 100% portable
// ============================================================

const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const url = require('node:url');
const crypto = require('node:crypto');
const db = require('./db');

const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'navibodega_maritime_key_super_secret_2026';
const PUBLIC_DIR = path.join(__dirname, 'public');

// --- TOKEN HELPERS ---
function signToken(payload, expiresInHours = 24) {
    const exp = Math.floor(Date.now() / 1000) + (expiresInHours * 3600);
    const body = { ...payload, exp };
    const encodedPayload = Buffer.from(JSON.stringify(body)).toString('base64url');
    const signature = crypto.createHmac('sha256', JWT_SECRET).update(encodedPayload).digest('base64url');
    return `${encodedPayload}.${signature}`;
}

function verifyToken(token) {
    if (!token || typeof token !== 'string' || !token.includes('.')) return null;
    const [payloadB64, signature] = token.split('.');
    const expectedSig = crypto.createHmac('sha256', JWT_SECRET).update(payloadB64).digest('base64url');
    if (signature !== expectedSig) return null;

    try {
        const payload = JSON.parse(Buffer.from(payloadB64, 'base64url').toString('utf8'));
        if (payload.exp && payload.exp < Math.floor(Date.now() / 1000)) {
            return null; // Expired
        }
        return payload;
    } catch {
        return null;
    }
}

// --- MIME TYPES FOR STATIC FILES ---
const MIME_TYPES = {
    '.html': 'text/html; charset=utf-8',
    '.css': 'text/css; charset=utf-8',
    '.js': 'application/javascript; charset=utf-8',
    '.json': 'application/json; charset=utf-8',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.svg': 'image/svg+xml',
    '.ico': 'image/x-icon'
};

// --- REQUEST HELPERS ---
function parseJsonBody(req) {
    return new Promise((resolve, reject) => {
        let body = '';
        req.on('data', chunk => {
            body += chunk;
            if (body.length > 5 * 1024 * 1024) { // 5MB limit
                reject(new Error('Payload too large'));
            }
        });
        req.on('end', () => {
            if (!body) return resolve({});
            try {
                resolve(JSON.parse(body));
            } catch (err) {
                reject(new Error('JSON inválido'));
            }
        });
        req.on('error', reject);
    });
}

function sendJson(res, statusCode, data) {
    res.writeHead(statusCode, {
        'Content-Type': 'application/json; charset=utf-8',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, PUT, PATCH, DELETE, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization'
    });
    res.end(JSON.stringify(data));
}

function sendError(res, statusCode, message) {
    sendJson(res, statusCode, { error: message, success: false });
}

function authenticate(req) {
    const authHeader = req.headers['authorization'];
    if (!authHeader || !authHeader.startsWith('Bearer ')) return null;
    const token = authHeader.substring(7).trim();
    return verifyToken(token);
}

// --- STATIC FILE SERVER ---
function serveStaticFile(req, res, pathname) {
    let safePath = pathname === '/' ? '/index.html' : pathname;
    let filePath = path.join(PUBLIC_DIR, safePath);

    // Prevent directory traversal
    if (!filePath.startsWith(PUBLIC_DIR)) {
        sendError(res, 403, 'Acceso prohibido');
        return;
    }

    fs.stat(filePath, (err, stats) => {
        if (err || !stats.isFile()) {
            // SPA fallback to index.html for non-API routes
            const indexPath = path.join(PUBLIC_DIR, 'index.html');
            fs.readFile(indexPath, (readErr, content) => {
                if (readErr) {
                    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
                    res.end('404 Recurso No Encontrado');
                } else {
                    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
                    res.end(content);
                }
            });
            return;
        }

        const ext = path.extname(filePath).toLowerCase();
        const contentType = MIME_TYPES[ext] || 'application/octet-stream';

        fs.readFile(filePath, (readErr, content) => {
            if (readErr) {
                sendError(res, 500, 'Error leyendo archivo');
                return;
            }
            res.writeHead(200, {
                'Content-Type': contentType,
                'Cache-Control': 'no-cache'
            });
            res.end(content);
        });
    });
}

// --- ROUTER HANDLER ---
const server = http.createServer(async (req, res) => {
    // Enable CORS preflight
    if (req.method === 'OPTIONS') {
        res.writeHead(204, {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET, POST, PUT, PATCH, DELETE, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type, Authorization',
            'Access-Control-Max-Age': '86400'
        });
        res.end();
        return;
    }

    const parsedUrl = url.parse(req.url, true);
    const pathname = parsedUrl.pathname;
    const method = req.method;

    // --- API ROUTES ---
    if (pathname.startsWith('/api/')) {
        try {
            // 1. AUTH: LOGIN
            if (method === 'POST' && pathname === '/api/auth/login') {
                const body = await parseJsonBody(req);
                const { email, password } = body;

                if (!email || !password) {
                    return sendError(res, 400, 'Correo electrónico y contraseña requeridos');
                }

                const user = db.getUserByEmail(email.trim());
                if (!user || !db.verifyPassword(password, user.password)) {
                    return sendError(res, 401, 'Credenciales inválidas. Verifique correo o clave.');
                }

                const token = signToken({
                    id: user.id,
                    email: user.email,
                    role: user.role,
                    name: user.name,
                    vessel_name: user.vessel_name
                });

                const { password: _, ...safeUser } = user;
                return sendJson(res, 200, {
                    success: true,
                    token,
                    user: safeUser,
                    message: `Bienvenido a bordo, ${user.name}`
                });
            }

            // 2. AUTH: REGISTER (CLIENT / SHIPPING AGENT)
            if (method === 'POST' && pathname === '/api/auth/register') {
                const body = await parseJsonBody(req);
                const { email, password, name, company, vessel_name, phone } = body;

                if (!email || !password || !name) {
                    return sendError(res, 400, 'Nombre, correo y contraseña son obligatorios');
                }

                if (password.length < 6) {
                    return sendError(res, 400, 'La contraseña debe tener al menos 6 caracteres');
                }

                const existing = db.getUserByEmail(email.trim());
                if (existing) {
                    return sendError(res, 409, 'Ya existe una cuenta registrada con este correo');
                }

                const newUser = db.createUser({
                    email: email.trim(),
                    password,
                    name: name.trim(),
                    role: 'cliente',
                    company: company ? company.trim() : '',
                    vessel_name: vessel_name ? vessel_name.trim() : 'Embarcación General',
                    vessel_imo: '',
                    phone: phone ? phone.trim() : ''
                });

                const token = signToken({
                    id: newUser.id,
                    email: newUser.email,
                    role: newUser.role,
                    name: newUser.name,
                    vessel_name: newUser.vessel_name
                });

                return sendJson(res, 201, {
                    success: true,
                    token,
                    user: newUser,
                    message: 'Cuenta creada con éxito.'
                });
            }

            // 3. AUTH: GET CURRENT USER (ME)
            if (method === 'GET' && pathname === '/api/auth/me') {
                const userClaims = authenticate(req);
                if (!userClaims) return sendError(res, 401, 'No autenticado o token vencido');

                const user = db.getUserById(userClaims.id);
                if (!user) return sendError(res, 404, 'Usuario no encontrado');

                return sendJson(res, 200, { success: true, user });
            }

            // 4. PRODUCTS: GET ALL
            if (method === 'GET' && pathname === '/api/products') {
                const products = db.getAllProducts();
                return sendJson(res, 200, { success: true, count: products.length, products });
            }

            // 5. PRODUCTS: CREATE (ADMIN)
            if (method === 'POST' && pathname === '/api/products') {
                const userClaims = authenticate(req);
                if (!userClaims || userClaims.role !== 'admin') {
                    return sendError(res, 403, 'Acceso restringido al Administrador de Bodega');
                }

                const body = await parseJsonBody(req);
                if (!body.name || !body.category || !body.unit || body.price === undefined) {
                    return sendError(res, 400, 'Faltan campos requeridos para el producto');
                }

                const newProd = db.createProduct(body);
                return sendJson(res, 201, { success: true, product: newProd, message: 'Producto ingresado al inventario' });
            }

            // 6. PRODUCTS: UPDATE (ADMIN)
            const prodMatch = pathname.match(/^\/api\/products\/([^/]+)$/);
            if (prodMatch) {
                const prodId = prodMatch[1];
                if (method === 'PUT') {
                    const userClaims = authenticate(req);
                    if (!userClaims || userClaims.role !== 'admin') {
                        return sendError(res, 403, 'Acceso restringido al Administrador');
                    }
                    const body = await parseJsonBody(req);
                    const updated = db.updateProduct(prodId, body);
                    if (!updated) return sendError(res, 404, 'Producto no encontrado');
                    return sendJson(res, 200, { success: true, product: updated, message: 'Producto actualizado' });
                }

                if (method === 'DELETE') {
                    const userClaims = authenticate(req);
                    if (!userClaims || userClaims.role !== 'admin') {
                        return sendError(res, 403, 'Acceso restringido al Administrador');
                    }
                    db.deleteProduct(prodId);
                    return sendJson(res, 200, { success: true, message: 'Producto removido del inventario' });
                }
            }

            // 7. ORDERS: LIST
            if (method === 'GET' && pathname === '/api/orders') {
                const userClaims = authenticate(req);
                if (!userClaims) return sendError(res, 401, 'No autenticado');

                let orders = [];
                if (userClaims.role === 'admin') {
                    orders = db.getAllOrders();
                } else {
                    orders = db.getOrdersByClientId(userClaims.id);
                }
                return sendJson(res, 200, { success: true, count: orders.length, orders });
            }

            // 8. ORDERS: CREATE NEW
            if (method === 'POST' && pathname === '/api/orders') {
                const userClaims = authenticate(req);
                if (!userClaims) return sendError(res, 401, 'Inicie sesión para enviar un pedido');

                const body = await parseJsonBody(req);
                const { vessel_name, captain, departure_date, notes, items, delivery_fee } = body;

                if (!vessel_name || !captain || !departure_date) {
                    return sendError(res, 400, 'Complete la información de embarcación, capitán y fecha de zarpado.');
                }

                if (!items || !Array.isArray(items) || items.length === 0) {
                    return sendError(res, 400, 'Debe incluir al menos un producto en la lista de víveres.');
                }

                const orderData = {
                    client_id: userClaims.id,
                    client_name: userClaims.name,
                    client_email: userClaims.email,
                    vessel_name: vessel_name.trim(),
                    vessel_imo: '',
                    captain: captain.trim(),
                    dock_port: '',
                    departure_date: departure_date.trim(),
                    status: 'Pendiente de Cotización',
                    notes: notes ? notes.trim() : '',
                    delivery_fee: deliveryFee !== undefined ? Number(deliveryFee) : 35.00
                };

                const createdOrder = db.createOrder(orderData, items);
                return sendJson(res, 201, {
                    success: true,
                    order: createdOrder,
                    message: `Solicitud de avituallamiento ${createdOrder.id} registrada con éxito en bodega.`
                });
            }

            // 9. ORDERS: SINGLE ORDER DETAILS
            const orderMatch = pathname.match(/^\/api\/orders\/([^/]+)$/);
            if (orderMatch && method === 'GET') {
                const userClaims = authenticate(req);
                if (!userClaims) return sendError(res, 401, 'No autenticado');

                const orderId = orderMatch[1];
                const order = db.getOrderById(orderId);
                if (!order) return sendError(res, 404, 'Pedido no encontrado');

                // If client, ensure they own the order
                if (userClaims.role !== 'admin' && order.client_id !== userClaims.id) {
                    return sendError(res, 403, 'No tiene autorización para visualizar este pedido');
                }

                return sendJson(res, 200, { success: true, order });
            }

            // 10. ORDERS: UPDATE STATUS (ADMIN OR CLIENT APPROVAL)
            const orderStatusMatch = pathname.match(/^\/api\/orders\/([^/]+)\/status$/);
            if (orderStatusMatch && method === 'PATCH') {
                const userClaims = authenticate(req);
                if (!userClaims) return sendError(res, 401, 'No autenticado');

                const orderId = orderStatusMatch[1];
                const order = db.getOrderById(orderId);
                if (!order) return sendError(res, 404, 'Pedido no encontrado');

                const body = await parseJsonBody(req);
                const { status, notes } = body;

                if (!status) return sendError(res, 400, 'Nuevo estado requerido');

                // Client can only approve or cancel their own quote
                if (userClaims.role !== 'admin') {
                    if (order.client_id !== userClaims.id) {
                        return sendError(res, 403, 'No autorizado');
                    }
                    if (status !== 'Aprobado por Cliente' && status !== 'Cancelado') {
                        return sendError(res, 400, 'Los clientes solo pueden aprobar o cancelar la cotización.');
                    }
                }

                const updated = db.updateOrderStatus(orderId, status, notes);
                return sendJson(res, 200, { success: true, order: updated, message: `Estado actualizado a "${status}"` });
            }

            // 11. ORDERS: QUOTE ADJUSTMENT (ADMIN ONLY)
            const orderQuoteMatch = pathname.match(/^\/api\/orders\/([^/]+)\/quote$/);
            if (orderQuoteMatch && method === 'PUT') {
                const userClaims = authenticate(req);
                if (!userClaims || userClaims.role !== 'admin') {
                    return sendError(res, 403, 'Acceso restringido al Administrador de Bodega');
                }

                const orderId = orderQuoteMatch[1];
                const body = await parseJsonBody(req);
                const { items, delivery_fee, admin_notes, status } = body;

                const updated = db.updateOrderQuote(orderId, items, delivery_fee, admin_notes, status);
                if (!updated) return sendError(res, 404, 'Pedido no encontrado');

                return sendJson(res, 200, {
                    success: true,
                    order: updated,
                    message: `Cotización de pedido ${orderId} guardada y actualizada.`
                });
            }

            // 12. STATS (ADMIN ONLY)
            if (method === 'GET' && pathname === '/api/stats') {
                const userClaims = authenticate(req);
                if (!userClaims || userClaims.role !== 'admin') {
                    return sendError(res, 403, 'Acceso restringido al Administrador');
                }
                const stats = db.getStats();
                return sendJson(res, 200, { success: true, stats });
            }

            // 13. USERS LIST (ADMIN ONLY)
            if (method === 'GET' && pathname === '/api/users') {
                const userClaims = authenticate(req);
                if (!userClaims || userClaims.role !== 'admin') {
                    return sendError(res, 403, 'Acceso restringido');
                }
                const users = db.getAllUsers();
                return sendJson(res, 200, { success: true, count: users.length, users });
            }

            // 14. ADMIN DATABASE RESET
            if (method === 'POST' && pathname === '/api/admin/reset') {
                const userClaims = authenticate(req);
                if (!userClaims || userClaims.role !== 'admin') {
                    return sendError(res, 403, 'Solo el Administrador puede restablecer los datos');
                }
                db.resetDatabase();
                return sendJson(res, 200, { success: true, message: 'Base de datos restablecida con datos marítimos de demostración.' });
            }

            return sendError(res, 404, `Ruta API no encontrada: ${method} ${pathname}`);
        } catch (err) {
            console.error('[NaviBodega Server Error]:', err);
            return sendError(res, 500, `Error interno del servidor: ${err.message}`);
        }
    }

    // --- STATIC FILES FALLBACK ---
    serveStaticFile(req, res, pathname);
});

// Start listening
server.listen(PORT, () => {
    console.log(`========================================================`);
    console.log(`🚢 NaviBodega Pro - Sistema de Avituallamiento Marítimo`);
    console.log(`========================================================`);
    console.log(`✓ Servidor activo en: http://localhost:${PORT}`);
    console.log(`✓ Motor de Datos: SQLite / JSON Store`);
    console.log(`✓ Usuarios de Demostración:`);
    console.log(`   - Administrador: admin@navibodega.com / admin123`);
    console.log(`   - Cliente Naval: capitan@pesquero.com / cliente123`);
    console.log(`========================================================`);
});
